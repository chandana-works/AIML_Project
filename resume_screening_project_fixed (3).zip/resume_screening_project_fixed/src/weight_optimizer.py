"""
Weight Optimizer Module  (Calculus component of the project)
---------------------------------------------------------------
Instead of guessing fixed weights for combining skill match score, CGPA,
and PUC percentage into one final score, we LEARN the weights from a
historical hiring dataset using Gradient Descent.

Model (linear combination):
    predicted = w1*skill_score + w2*cgpa_norm + w3*puc_norm + b

Loss function (Mean Squared Error):
    L = (1/n) * sum( (y_true - predicted)^2 )

This is where calculus comes in. To reduce the loss, we need to know the
DIRECTION in which each weight should change - that direction is given by
the loss function's PARTIAL DERIVATIVE with respect to each weight
(the gradient):

    dL/dw_i = -(2/n) * sum( (y_true - predicted) * x_i )
    dL/db   = -(2/n) * sum( y_true - predicted )

Gradient Descent repeatedly nudges each weight in the direction that
reduces the loss the fastest:

    w_i = w_i - learning_rate * dL/dw_i

This is the exact same calculus principle used to train models like
Logistic Regression or Neural Networks - we are just applying it directly,
by hand, to our own 3-feature scoring model so the math is fully visible.
"""

import csv


def load_training_data(path):
    X, y = [], []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            X.append([
                float(row["skill_match_score"]),
                float(row["cgpa_norm"]),
                float(row["puc_norm"]),
            ])
            y.append(float(row["shortlisted"]))
    return X, y


def predict(features, weights, bias):
    """predicted = w1*x1 + w2*x2 + w3*x3 + b"""
    return sum(w * x for w, x in zip(weights, features)) + bias


def mean_squared_error(y_true, y_pred):
    n = len(y_true)
    return sum((yt - yp) ** 2 for yt, yp in zip(y_true, y_pred)) / n


def compute_gradients(X, y_true, y_pred):
    """
    Computes dL/dw1, dL/dw2, dL/dw3, dL/db -- the partial derivatives of
    the MSE loss with respect to each weight and the bias.
    """
    n = len(y_true)
    num_features = len(X[0])
    grad_w = [0.0] * num_features
    grad_b = 0.0

    for features, yt, yp in zip(X, y_true, y_pred):
        error = yt - yp
        for i in range(num_features):
            grad_w[i] += -(2 / n) * error * features[i]
        grad_b += -(2 / n) * error

    return grad_w, grad_b


def train(X, y, learning_rate=0.5, epochs=500, verbose=False):
    """
    Trains the weighted scoring model using gradient descent.
    Returns: learned weights [w1, w2, w3], bias, and loss history.
    """
    num_features = len(X[0])
    weights = [0.33] * num_features  # start near equal weighting
    bias = 0.0
    loss_history = []

    for epoch in range(epochs):
        y_pred = [predict(features, weights, bias) for features in X]
        loss = mean_squared_error(y, y_pred)
        loss_history.append(loss)

        grad_w, grad_b = compute_gradients(X, y, y_pred)
        weights = [w - learning_rate * g for w, g in zip(weights, grad_w)]
        bias = bias - learning_rate * grad_b

        if verbose and epoch % 100 == 0:
            print(f"  Epoch {epoch:4d} | Loss: {loss:.5f} | Weights: "
                  f"{[round(w, 3) for w in weights]} | Bias: {round(bias, 3)}")

    return weights, bias, loss_history


# ===========================================================================
# EXTENSION 1 - Logistic regression trained by gradient descent
# ===========================================================================
# The shortlisting label is binary (0/1). Fitting it with MSE on a linear
# model (above) is the weaker choice: predictions are not probabilities and
# the loss is not matched to the label. Logistic regression fixes both:
#
#     p      = sigmoid(w.x + b)                       sigmoid(z) = 1/(1+e^-z)
#     Loss   = -(1/n) sum[ y*log(p) + (1-y)*log(1-p) ] + (lambda/2)*||w||^2
#     dL/dw  = (1/n) * X^T (p - y) + lambda*w         <- the calculus part
#     dL/db  = (1/n) * sum(p - y)
#
# The gradient has the same neat "error x input" form as the linear case,
# which is a nice teaching point for the calculus component.
# ===========================================================================

import numpy as np


def sigmoid(z):
    z = np.clip(z, -35, 35)
    return 1.0 / (1.0 + np.exp(-z))


def cross_entropy(y, p, eps=1e-12):
    p = np.clip(p, eps, 1 - eps)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def train_logistic(X, y, learning_rate=0.5, epochs=2000, l2=0.001, verbose=False,
                   standardize=True):
    """Batch gradient descent for L2-regularised logistic regression.

    With standardize=True the features are z-scored INSIDE the optimiser
    (well-conditioned problem -> fast, reliable convergence) and the learned
    weights are mapped back to the raw [0,1] feature scale afterwards:

        w_raw = w_std / sigma ,   b_raw = b_std - sum(w_std * mu / sigma)

    so the returned model is used exactly like before on raw features.
    Returns (weights list, bias float, loss_history list).
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n, d = X.shape
    if standardize:
        mu = X.mean(axis=0)
        sigma = X.std(axis=0)
        sigma[sigma < 1e-12] = 1.0
        Z = (X - mu) / sigma
    else:
        mu, sigma, Z = np.zeros(d), np.ones(d), X

    w = np.zeros(d)
    b = 0.0
    history = []
    for epoch in range(epochs):
        p = sigmoid(Z @ w + b)
        loss = cross_entropy(y, p) + 0.5 * l2 * float(w @ w)
        history.append(loss)
        grad_w = Z.T @ (p - y) / n + l2 * w       # dL/dw
        grad_b = float(np.mean(p - y))            # dL/db
        w -= learning_rate * grad_w
        b -= learning_rate * grad_b
        if verbose and epoch % 500 == 0:
            print(f"  Epoch {epoch:4d} | Loss: {loss:.5f}")

    w_raw = w / sigma
    b_raw = b - float(np.sum(w * mu / sigma))
    return [float(v) for v in w_raw], float(b_raw), history


def train_linear_np(X, y, learning_rate=0.05, epochs=500):
    """Vectorised twin of `train` (same MSE gradient), used for fast
    cross-validation. Verified equal to `train` in tests/."""
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n, d = X.shape
    w = np.full(d, 0.33)
    b = 0.0
    for _ in range(epochs):
        err = y - (X @ w + b)
        w -= learning_rate * (-(2 / n) * (X.T @ err))
        b -= learning_rate * (-(2 / n) * float(err.sum()))
    return [float(v) for v in w], float(b)


class ScoringModel:
    """Container for the learned scoring function so the rest of the code
    (pipeline, explainer, simulator, web app) is model-agnostic.

    kind = "logistic" -> p = sigmoid(w.x + b)      (default, recommended)
    kind = "linear"   -> p = clip(w.x + b, 0, 1)   (original MSE model)
    """

    FEATURES = ["skill_match", "cgpa", "puc"]

    def __init__(self, kind, weights, bias, feature_means, loss_history=None,
                 n_train=0):
        self.kind = kind
        self.weights = list(weights)
        self.bias = float(bias)
        self.feature_means = list(feature_means)
        self.loss_history = list(loss_history or [])
        self.n_train = n_train
        self.l2 = 0.0
        self.background = []   # sample of training feature rows (for SHAP)

    def raw(self, features):
        return sum(w * x for w, x in zip(self.weights, features)) + self.bias

    def predict(self, features):
        z = self.raw(features)
        if self.kind == "logistic":
            return float(sigmoid(z))
        return max(0.0, min(z, 1.0))

    def to_dict(self):
        return {"kind": self.kind, "weights": self.weights, "bias": self.bias,
                "feature_means": self.feature_means, "features": self.FEATURES,
                "l2": self.l2, "n_train": self.n_train}


L2_GRID = (0.001, 0.01, 0.05, 0.2, 1.0, 3.0)


def select_l2(X, y, grid=L2_GRID, folds=5, seed=0):
    """Choose the L2 strength by cross-validated log-loss with the
    ONE-STANDARD-ERROR rule: take the most regularised setting whose CV loss
    is within one standard error of the best. On small / nearly separable data
    this avoids exploding weights and scores pinned at 0% / 100%; on large
    data the standard error is tiny so a weak penalty is chosen."""
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(y)
    if n < 2 * folds:
        return 0.2
    idx = np.random.RandomState(seed).permutation(n)
    parts = np.array_split(idx, folds)
    stats = []
    for lam in grid:
        losses = []
        for k in range(folds):
            te = parts[k]
            tr = np.concatenate([parts[j] for j in range(folds) if j != k])
            w, b, _ = train_logistic(X[tr], y[tr], l2=lam, epochs=600)
            losses.append(cross_entropy(y[te], sigmoid(X[te] @ np.array(w) + b)))
        stats.append((lam, float(np.mean(losses)), float(np.std(losses) / np.sqrt(folds))))
    best = min(stats, key=lambda t: t[1])
    limit = best[1] + best[2]
    return max(lam for lam, mean, _ in stats if mean <= limit)


def fit_model(X, y, kind="logistic", l2="auto"):
    """Train and wrap a ScoringModel. `kind` is 'logistic' or 'linear'."""
    means = [sum(col) / len(col) for col in zip(*X)]
    step = max(1, len(X) // 300)
    background = [list(row) for row in X[::step]][:300]
    if kind == "logistic":
        lam = select_l2(X, y) if l2 == "auto" else l2
        w, b, hist = train_logistic(X, y, l2=lam)
        model = ScoringModel(kind, w, b, means, hist, n_train=len(y))
        model.l2 = lam
        model.background = background
        return model
    elif kind == "linear":
        w, b, hist = train(X, y, learning_rate=0.05, epochs=500)
        model = ScoringModel(kind, w, b, means, hist, n_train=len(y))
        model.l2 = 0.0
        model.background = background
        return model
    raise ValueError(f"Unknown model kind: {kind!r}")


# sklearn-style wrappers (fit / predict_proba) so the hand-written gradient
# descent models can be benchmarked next to scikit-learn models.
class GDLogisticClassifier:
    def __init__(self, learning_rate=0.5, epochs=2000, l2=0.001):
        self.learning_rate, self.epochs, self.l2 = learning_rate, epochs, l2

    def fit(self, X, y):
        self.w_, self.b_, _ = train_logistic(X, y, self.learning_rate, self.epochs, self.l2)
        return self

    def predict_proba(self, X):
        p = sigmoid(np.asarray(X, dtype=float) @ np.array(self.w_) + self.b_)
        return np.column_stack([1 - p, p])


class GDLinearClassifier:
    def __init__(self, learning_rate=0.05, epochs=500):
        self.learning_rate, self.epochs = learning_rate, epochs

    def fit(self, X, y):
        self.w_, self.b_ = train_linear_np(X, y, self.learning_rate, self.epochs)
        return self

    def predict_proba(self, X):
        p = np.clip(np.asarray(X, dtype=float) @ np.array(self.w_) + self.b_, 0, 1)
        return np.column_stack([1 - p, p])
