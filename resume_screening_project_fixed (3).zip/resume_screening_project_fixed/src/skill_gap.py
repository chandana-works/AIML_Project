"""Skill gap and course recommendation utilities."""

import csv
from urllib.parse import quote_plus


def compute_skill_gap(resume_skills, job_skills):
    return sorted(job_skills - resume_skills)


def load_course_catalog(path):
    catalog = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            catalog[row["skill"].strip().lower()] = {
                "course_name": row["course_name"].strip(),
                "platform": row["platform"].strip(),
                "course_url": row.get("course_url", "").strip(),
            }
    return catalog


COURSE_PLATFORMS = (
    ("Coursera", "https://www.coursera.org/search?query="),
    ("Udemy", "https://www.udemy.com/courses/search/?q="),
)


def search_links(query):
    """Search-result links on each learning platform for any skill/course name.
    Used so EVERY missing skill gets a working link, even without a catalog row."""
    q = quote_plus(query)
    return [{"platform": name, "url": base + q} for name, base in COURSE_PLATFORMS]


def recommend_courses(missing_skills, catalog):
    """One recommendation per missing skill. Curated catalog rows are used when
    available (with a link auto-filled if the catalog row has none); otherwise
    Coursera and Udemy search links are generated automatically."""
    recommendations = {}
    for skill in missing_skills:
        row = catalog.get(skill)
        if row:
            rec = dict(row)
            rec["auto"] = False
            rec["links"] = search_links(rec["course_name"] if rec.get("course_name") else f"{skill} course")
            if not rec.get("course_url"):
                rec["course_url"] = rec["links"][0]["url"]
        else:
            links = search_links(f"{skill} course")
            rec = {
                "course_name": f"Find {skill} courses",
                "platform": "Coursera / Udemy",
                "course_url": links[0]["url"],
                "auto": True,
                "links": links,
            }
        recommendations[skill] = rec
    return recommendations
