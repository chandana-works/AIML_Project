"""
Human annotation support (gold labels for evaluation)
-----------------------------------------------------
Two annotators independently judge the SAME set of resume-job pairs
("Would you shortlist this candidate for an interview?") without seeing the
model score or the rule label. Agreement is reported with Cohen's kappa and
only pairs on which both annotators agree become gold labels.
"""

import csv
import os
import re
import threading
from datetime import datetime, timezone

FIELDS = ["timestamp", "annotator", "pair_id", "resume_id", "job_id", "label", "note"]
LABELS = {"1", "0", "unsure"}
_LOCK = threading.Lock()


def valid_annotator(name):
    return bool(re.fullmatch(r"[A-Za-z0-9_-]{1,20}", name or ""))


def _read(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def load_pairs(path):
    return _read(path)


def load_annotations(path):
    return _read(path)


def next_pair(pairs, annotations, annotator):
    """First pair this annotator has not labelled yet (pairs are in a fixed shuffled order)."""
    done = {a["pair_id"] for a in annotations if a["annotator"] == annotator}
    for i, p in enumerate(pairs, start=1):
        if p["pair_id"] not in done:
            return i, p
    return None, None


def append_annotation(path, annotator, pair, label, note=""):
    if label not in LABELS:
        raise ValueError("Choose Suitable, Not suitable or Unsure.")
    if not valid_annotator(annotator):
        raise ValueError("Invalid annotator id.")
    row = {"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "annotator": annotator, "pair_id": pair["pair_id"], "resume_id": pair["resume_id"],
           "job_id": pair["job_id"], "label": label, "note": (note or "").strip()[:300]}
    with _LOCK:
        new = not os.path.exists(path) or os.path.getsize(path) == 0
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            if new:
                w.writeheader()
            w.writerow(row)
    return row


def cohen_kappa(a, b):
    n = len(a)
    if n == 0:
        return float("nan")
    po = sum(x == y for x, y in zip(a, b)) / n
    classes = set(a) | set(b)
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in classes)
    if pe == 1:
        return 1.0 if po == 1 else float("nan")
    return (po - pe) / (1 - pe)


def kappa_band(k):
    """Landis & Koch (1977) verbal bands."""
    if k != k:
        return "n/a"
    for lim, name in ((0.0, "poor"), (0.2, "slight"), (0.4, "fair"), (0.6, "moderate"),
                      (0.8, "substantial"), (1.01, "almost perfect")):
        if k < lim:
            return name
    return "almost perfect"


def analyse(annotations):
    """Pairwise stats for the first two annotators (alphabetical) on shared pairs.

    Returns dict with kappa, agreement, gold {pair_id: label}, disagreements, counts.
    'unsure' labels are excluded from agreement and from gold.
    """
    by_pair = {}
    for a in annotations:
        by_pair.setdefault(a["pair_id"], {})[a["annotator"]] = a
    annotators = sorted({a["annotator"] for a in annotations})
    res = {"annotators": annotators, "n_pairs_seen": len(by_pair), "gold": {}, "disagreements": [],
           "unsure": 0, "kappa": float("nan"), "agreement": float("nan"), "n_compared": 0}
    if len(annotators) < 2:
        return res
    a_name, b_name = annotators[0], annotators[1]
    xs, ys = [], []
    for pid, d in sorted(by_pair.items()):
        if a_name not in d or b_name not in d:
            continue
        la, lb = d[a_name]["label"], d[b_name]["label"]
        if "unsure" in (la, lb):
            res["unsure"] += 1
            continue
        xs.append(la); ys.append(lb)
        meta = d[a_name]
        if la == lb:
            res["gold"][pid] = {"label": int(la), "resume_id": meta["resume_id"], "job_id": meta["job_id"]}
        else:
            res["disagreements"].append({"pair_id": pid, "resume_id": meta["resume_id"],
                                         "job_id": meta["job_id"], a_name: la, b_name: lb})
    res["n_compared"] = len(xs)
    res["kappa"] = cohen_kappa(xs, ys)
    res["agreement"] = sum(x == y for x, y in zip(xs, ys)) / len(xs) if xs else float("nan")
    return res
