"""
Pipeline Module
-----------------
Wires every component together for one resume-job pair:

  1. Extract skills from both resume and job description (Phrase + Fuzzy
     Matching against the skills taxonomy).
  2. Compute Skill Overlap Score and Text Similarity Score (TF-IDF +
     Cosine Similarity).
  3. Normalize academic scores (Min-Max Normalization).
  4. Combine everything into one Final Score using the GRADIENT-DESCENT
     LEARNED model (logistic regression by default; see weight_optimizer).
  5. Compute the skill gap (set difference) and course recommendations.

Produces two outputs for the same resume-job pair:
  - baseline_output : final score only   (what existing systems give)
  - full_output      : final score + missing skills + course recommendations
                        (this project's contribution)
"""

from src import skill_extraction, matching, academic_score, skill_gap


def build_job_text(job_row):
    return f"{job_row['job_role']} {job_row['description']} {job_row['skills_required'].replace(';', ' ')}"


def build_resume_text(resume_row):
    return f"{resume_row['target_role']} {resume_row['skills'].replace(';', ' ')}"


def _num_or_none(value):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return None


def score_pair(resume_row, job_row, model, taxonomy=None):
    """Computes all intermediate scores for one resume-job pair.

    `model` is a weight_optimizer.ScoringModel (logistic or linear). If the
    candidate's CGPA or PUC % is blank, the training-set mean is used for that
    feature (a neutral value: it contributes 0 in the explanation) and the
    field is listed in `imputed` so the UI can say so.
    """
    resume_skills = skill_extraction.parse_semicolon_list(resume_row["skills"])
    job_skills = skill_extraction.parse_semicolon_list(job_row["skills_required"])

    skill_score = matching.skill_overlap_score(resume_skills, job_skills)
    text_score = matching.text_similarity_score(
        build_resume_text(resume_row), build_job_text(job_row)
    )

    imputed = []
    cgpa = _num_or_none(resume_row.get("cgpa"))
    puc = _num_or_none(resume_row.get("puc_percentage"))
    if cgpa is None:
        cgpa_norm = model.feature_means[1]
        imputed.append("CGPA")
    else:
        cgpa_norm = academic_score.normalize_cgpa(cgpa)
    if puc is None:
        puc_norm = model.feature_means[2]
        imputed.append("PUC %")
    else:
        puc_norm = academic_score.normalize_percentage(puc)

    features = [skill_score, cgpa_norm, puc_norm]
    final_score = model.predict(features)

    return {
        "resume_skills": resume_skills,
        "job_skills": job_skills,
        "skill_score": skill_score,
        "text_similarity_score": text_score,
        "cgpa_norm": cgpa_norm,
        "puc_norm": puc_norm,
        "features": features,
        "imputed": imputed,
        "final_score": final_score,
    }


def generate_baseline_output(scores):
    """What a conventional system gives: a plain match score."""
    return {
        "match_score_percent": round(scores["final_score"] * 100, 1),
    }


def generate_full_output(scores, catalog):
    """This project's contribution: score + gap + recommendations."""
    missing = skill_gap.compute_skill_gap(scores["resume_skills"], scores["job_skills"])
    recommendations = skill_gap.recommend_courses(missing, catalog)
    return {
        "match_score_percent": round(scores["final_score"] * 100, 1),
        "missing_skills": missing,
        "course_recommendations": recommendations,
    }
