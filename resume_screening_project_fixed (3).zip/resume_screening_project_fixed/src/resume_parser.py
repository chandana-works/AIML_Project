
import re
from pypdf import PdfReader


def extract_resume_text(pdf_path):
    """Extract selectable text from a PDF resume."""
    reader = PdfReader(pdf_path)
    pages = []

    for page in reader.pages:
        pages.append(page.extract_text() or "")

    return "\n".join(pages).strip()


def find_first(patterns, text):
    """Return the first regex match, or None."""
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return None


def extract_resume_details(text):
    """Extract common contact and academic details from resume text."""

    email = find_first(
        [r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b"],
        text,
    )

    phone = find_first(
        [
            r"(?:\+?\d[\d\s().-]{8,}\d)"
        ],
        text,
    )

    cgpa = find_first(
        [
            r"(?:CGPA|C\.G\.P\.A\.?)\s*[:\-]?\s*"
            r"([0-9]{1,2}(?:\.[0-9]+)?)"
        ],
        text,
    )

    puc_percentage = find_first(
        [
            r"(?:PUC|12th|12th\s+standard|HSC|higher\s+secondary)"
            r"[\s\S]{0,100}?"
            r"([0-9]{1,3}(?:\.[0-9]+)?)\s*%"
        ],
        text,
    )

    if cgpa is not None:
        value = float(cgpa)
        if not 0 <= value <= 10:
            cgpa = None

    if puc_percentage is not None:
        value = float(puc_percentage)
        if not 0 <= value <= 100:
            puc_percentage = None

    return {
        "email": email,
        "phone": phone,
        "cgpa": cgpa,
        "puc_percentage": puc_percentage,
        "resume_text": text,
    }


def parse_resume(pdf_path):
    """Extract text and candidate details from a PDF resume."""
    text = extract_resume_text(pdf_path)

    if not text:
        raise ValueError(
            "No selectable text found. This PDF may be scanned; "
            "OCR may be required."
        )

    return extract_resume_details(text)
