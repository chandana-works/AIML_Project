"""
Optional Sentence-BERT semantic similarity.

Needs `pip install sentence-transformers` and internet access ONCE to download
the model, so it is NOT part of the default offline pipeline. Used as an extra
comparison arm in evaluate/evaluate_on_human_labels.py (--sbert).
`encoder` is any object with .encode(list_of_str) -> 2-D array, so tests can
inject a stub.
"""

DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def load_encoder(name=DEFAULT_MODEL):
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError("Install sentence-transformers (pip install sentence-transformers) "
                           "on a machine with internet access to use SBERT.") from exc
    return SentenceTransformer(name)


def cosine_scores(encoder, texts_a, texts_b):
    import numpy as np
    A = np.asarray(encoder.encode(list(texts_a)), dtype=float)
    B = np.asarray(encoder.encode(list(texts_b)), dtype=float)
    A /= np.linalg.norm(A, axis=1, keepdims=True) + 1e-12
    B /= np.linalg.norm(B, axis=1, keepdims=True) + 1e-12
    return (A * B).sum(axis=1).tolist()
