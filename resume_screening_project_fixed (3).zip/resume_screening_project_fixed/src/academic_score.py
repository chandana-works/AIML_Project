"""
Academic Score Module
-----------------------
CGPA (typically out of 10) and percentages (out of 100) are on different
scales and can't be combined directly. We apply Min-Max Normalization to
bring both onto a common [0, 1] scale before combining them with the
skill match score.

    normalized_value = (value - min) / (max - min)

For CGPA, min=0 and max=10. For percentages, min=0 and max=100. These are
simplified (fixed-bound) special cases of min-max scaling.
"""


def normalize_cgpa(cgpa, max_cgpa=10.0):
    cgpa = max(0.0, min(cgpa, max_cgpa))  # clip to valid range
    return cgpa / max_cgpa


def normalize_percentage(pct, max_pct=100.0):
    pct = max(0.0, min(pct, max_pct))  # clip to valid range
    return pct / max_pct
