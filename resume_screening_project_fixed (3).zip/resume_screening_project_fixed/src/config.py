"""Dataset selection shared by app.py and main.py.

DATASET=scaled  -> data/scaled   (default when that folder exists)
DATASET=base    -> data/         (the original 12-job / 12-resume sample)
DATASET=<name>  -> data/<name>   (e.g. a folder built from the Kaggle data)
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def resolve_data_dir():
    choice = os.environ.get("DATASET", "").strip()
    scaled = ROOT / "data" / "scaled"
    if choice in ("", "scaled"):
        if (scaled / "job_postings.csv").exists():
            return scaled
        return ROOT / "data"
    if choice in ("base", "small"):
        return ROOT / "data"
    path = ROOT / "data" / choice
    if not (path / "job_postings.csv").exists():
        raise SystemExit(f"DATASET={choice!r}: {path}/job_postings.csv not found")
    return path
