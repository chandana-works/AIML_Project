"""
Prioritised Learning Path
-------------------------
Turns the unordered "missing skills" set into an ordered study plan.

Each missing skill s gets a priority score in [0, 1]:

    priority(s) = 0.40 * demand(s)      share of ALL job postings that require s
                + 0.30 * unlock(s)      how many other missing skills build on s
                                        (via the prerequisite graph)
                + 0.20 * affinity(s)    co-occurrence with skills the candidate
                                        already has: mean P(s | c) over the
                                        candidate's skills c, from job postings
                + 0.10 * quick_win(s)   1 - hours(s)/max_hours  (cheap skills first)

Each term is min-max scaled over the candidate's missing set. The four
weights are transparent heuristics (PRIORITY_WEIGHTS) - they can be tuned or
replaced by a learned ranker in future work.

ORDER: skills are sequenced with a topological sort of the prerequisite graph
(prerequisites always come before the skills that need them, e.g. SQL before
Power BI); among skills that are ready at the same time the higher priority
goes first.

Learning-time estimates come from data/skill_meta.csv (rough self-study hours;
editable assumptions, not measurements).
"""

import csv
from collections import Counter
from itertools import combinations

PRIORITY_WEIGHTS = {"demand": 0.40, "unlock": 0.30, "affinity": 0.20, "quick_win": 0.10}
HOURS_PER_WEEK = 8
DEFAULT_HOURS = 30


def load_skill_meta(path):
    """-> {skill: {"hours": int, "prerequisites": [skills]}}"""
    meta = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            skill = row["skill"].strip().lower()
            prereqs = [p.strip().lower() for p in (row.get("prerequisites") or "").split("|") if p.strip()]
            meta[skill] = {"hours": int(row.get("hours") or DEFAULT_HOURS), "prerequisites": prereqs}
    return meta


def build_corpus_stats(jobs):
    """Document frequency and pairwise co-occurrence of skills over job postings."""
    df, co = Counter(), Counter()
    for job in jobs:
        skills = {s.strip().lower() for s in (job.get("skills_required") or "").split(";") if s.strip()}
        df.update(skills)
        for a, b in combinations(sorted(skills), 2):
            co[(a, b)] += 1
    return {"n_jobs": len(jobs), "df": df, "co": co}


def _co(stats, a, b):
    return stats["co"].get((a, b) if a < b else (b, a), 0)


def _ancestors(skill, meta, cache):
    if skill in cache:
        return cache[skill]
    cache[skill] = set()  # guards against accidental cycles
    out = set()
    for p in meta.get(skill, {}).get("prerequisites", []):
        out.add(p)
        out |= _ancestors(p, meta, cache)
    cache[skill] = out
    return out


def _minmax(values):
    lo, hi = min(values.values()), max(values.values())
    if hi - lo < 1e-12:
        return {k: (1.0 if hi > 0 else 0.0) for k in values}
    return {k: (v - lo) / (hi - lo) for k, v in values.items()}


def build_learning_path(missing_skills, resume_skills, stats, meta, catalog=None,
                        weights=PRIORITY_WEIGHTS, hours_per_week=HOURS_PER_WEEK):
    missing = sorted(set(missing_skills))
    if not missing:
        return {"steps": [], "total_hours": 0, "total_weeks": 0}

    n = max(stats["n_jobs"], 1)
    cache = {}
    anc = {s: _ancestors(s, meta, cache) for s in missing}
    # dependency edges restricted to the missing set (transitive via full graph)
    deps = {s: sorted(anc[s] & set(missing)) for s in missing}

    demand = {s: stats["df"].get(s, 0) / n for s in missing}
    unlock = {s: float(sum(1 for t in missing if s in deps[t])) for s in missing}
    have = [c for c in resume_skills if stats["df"].get(c, 0) > 0]
    affinity = {}
    for s in missing:
        if have:
            affinity[s] = sum(_co(stats, s, c) / stats["df"][c] for c in have) / len(have)
        else:
            affinity[s] = 0.0
    hours = {s: meta.get(s, {}).get("hours", DEFAULT_HOURS) for s in missing}
    max_h = max(hours.values())
    quick = {s: 1.0 - hours[s] / max_h if max_h else 0.0 for s in missing}

    nd, nu, na = _minmax(demand), _minmax(unlock), _minmax(affinity)
    priority = {s: weights["demand"] * nd[s] + weights["unlock"] * nu[s]
                   + weights["affinity"] * na[s] + weights["quick_win"] * quick[s]
                for s in missing}

    # topological order, highest priority first among the ready skills
    remaining, order = set(missing), []
    while remaining:
        ready = [s for s in remaining if not (set(deps[s]) & remaining)]
        if not ready:  # cycle safety net
            ready = list(remaining)
        ready.sort(key=lambda s: (-priority[s], s))
        pick = ready[0]
        order.append(pick)
        remaining.discard(pick)

    steps, cum = [], 0
    for i, s in enumerate(order, start=1):
        cum += hours[s]
        steps.append({
            "rank": i,
            "skill": s,
            "priority": round(priority[s], 3),
            "demand_pct": round(100 * demand[s], 1),
            "unlocks": int(unlock[s]),
            "hours": hours[s],
            "cum_hours": cum,
            "prerequisites": deps[s],
            "course": (catalog or {}).get(s),
        })
    return {"steps": steps, "total_hours": cum,
            "total_weeks": round(cum / hours_per_week, 1),
            "hours_per_week": hours_per_week}
