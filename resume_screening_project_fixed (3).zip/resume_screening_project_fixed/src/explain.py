"""
Explainability Module  (exact Shapley values for the match score)
-----------------------------------------------------------------
With only three input features we can compute EXACT interventional SHAP
values by enumerating all 2^3 feature subsets - no external library, no
sampling approximation.

    v(S)   = average model output when the features in S are fixed to the
             candidate's values and the others are drawn from the training data
             (the 'background' sample stored in the model)
    phi_i  = sum over subsets S not containing i of
             |S|! (n-|S|-1)! / n!  *  ( v(S U {i}) - v(S) )

Properties (checked in tests/):
    v({}) = base value = average predicted score of the training population
    base + phi_1 + phi_2 + phi_3 = the candidate's score        (additivity)

Read it as: "relative to a typical applicant (base value), skill match
added +X points, CGPA added +Y, PUC % added +Z".
"""

from itertools import combinations
from math import factorial

import numpy as np

LABELS = {"skill_match": "Skill match", "cgpa": "CGPA", "puc": "PUC %"}


def _value(model, x, subset, background):
    """E[ f(x_S, X_~S) ] over the background rows."""
    rows = np.array(background, dtype=float).copy()
    for i in subset:
        rows[:, i] = x[i]
    w = np.array(model.weights)
    z = rows @ w + model.bias
    if model.kind == "logistic":
        out = 1.0 / (1.0 + np.exp(-np.clip(z, -35, 35)))
    else:
        out = np.clip(z, 0.0, 1.0)
    return float(out.mean())


def shapley_values(model, features, background=None):
    background = background or model.background or [model.feature_means]
    n = len(features)
    cache = {}

    def v(subset):
        key = tuple(sorted(subset))
        if key not in cache:
            cache[key] = _value(model, features, key, background)
        return cache[key]

    phi = []
    for i in range(n):
        others = [j for j in range(n) if j != i]
        total = 0.0
        for size in range(n):
            weight = factorial(size) * factorial(n - size - 1) / factorial(n)
            for S in combinations(others, size):
                total += weight * (v(S + (i,)) - v(S))
        phi.append(total)
    return v(()), phi


def explain_score(model, features):
    base, phi = shapley_values(model, features)
    final = model.predict(features)
    items = []
    for name, x, m, ph in zip(model.FEATURES, features, model.feature_means, phi):
        items.append({
            "feature": name,
            "label": LABELS.get(name, name),
            "value": x,
            "average": m,
            "contribution": 100.0 * ph,
        })
    items.sort(key=lambda it: -abs(it["contribution"]))
    max_abs = max([abs(it["contribution"]) for it in items] + [1e-9])
    for it in items:
        it["bar_pct"] = 100.0 * abs(it["contribution"]) / max_abs
    return {"baseline": 100.0 * base, "final": 100.0 * final, "items": items,
            "top_driver": items[0]["label"] if items else ""}
