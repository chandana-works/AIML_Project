"""
Job Recommender
----------------------------------
Reuses the project's trained scorer through a `score_fn(resume_row, job_row)`
callable that returns (percent, scores, full). Keeping the scorer injected
makes these functions easy to test and independent of pipeline internals.
"""


def _matched_missing(scores):
    resume_skills = {s.lower() for s in scores.get("resume_skills", [])}
    job_skills = {s.lower() for s in scores.get("job_skills", [])}
    return sorted(job_skills & resume_skills), sorted(job_skills - resume_skills)


def recommend_jobs(resume_row, jobs, score_fn, top_n=10):
    """Rank every job for one resume. Ties are broken by fewer missing skills."""
    results = []
    for job in jobs:
        percent, scores, _full = score_fn(resume_row, job)
        matched, missing = _matched_missing(scores)
        results.append({
            "job_id": job["job_id"], "job_role": job.get("job_role", ""),
            "company": job.get("company", ""), "score": round(percent, 1),
            "matched": matched, "missing": missing, "n_missing": len(missing),
        })
    results.sort(key=lambda r: (-r["score"], r["n_missing"], r["job_id"]))
    for i, r in enumerate(results, 1):
        r["rank"] = i
    return results[:top_n]


def skill_demand_summary(jobs, resume_skills, top_n=10):
    """Most-requested skills across all jobs the candidate does NOT yet have."""
    have = {s.lower() for s in resume_skills}
    counts = {}
    for job in jobs:
        for s in (job.get("skills_required") or "").split(";"):
            s = s.strip().lower()
            if s and s not in have:
                counts[s] = counts.get(s, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:top_n]
    total = len(jobs) or 1
    return [{"skill": s, "jobs": c, "percent": round(100 * c / total, 1)} for s, c in ranked]
