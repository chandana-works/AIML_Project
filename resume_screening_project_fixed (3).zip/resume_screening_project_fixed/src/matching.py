"""
Matching Module
----------------
Computes how well a resume matches a job posting, two ways:

1. Skill Overlap Score  - what fraction of the job's REQUIRED skills are
   present in the resume's skill set. This is the primary, most
   interpretable signal, and feeds directly into gap detection.

2. Text Similarity Score - TF-IDF vectorizes the full resume text and job
   description, then measures Cosine Similarity between them. This catches
   overall contextual fit beyond just the skill list (e.g. role wording,
   domain terms).
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def skill_overlap_score(resume_skills, job_skills):
    """
    Fraction of the job's required skills that the candidate already has.
    Returns a value in [0, 1]. This is the score skill-gap detection and
    the weighted model both build on.
    """
    if not job_skills:
        return 0.0
    overlap = resume_skills.intersection(job_skills)
    return len(overlap) / len(job_skills)


def text_similarity_score(resume_text, job_text):
    """
    TF-IDF + Cosine Similarity between full resume text and job
    description text. Returns a value in [0, 1].
    """
    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf_matrix = vectorizer.fit_transform([resume_text, job_text])
    sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    return float(sim[0][0])
