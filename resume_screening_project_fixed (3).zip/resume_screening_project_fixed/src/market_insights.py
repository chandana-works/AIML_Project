"""
Market Insights (localization evidence)
---------------------------------------
Aggregates the job postings and the candidate pool to show what the
(Indian) tech market asks for and where candidates fall short.

    demand(s) = % of job postings requiring skill s
    supply(s) = % of candidate resumes listing skill s
    gap(s)    = demand(s) - supply(s)      (positive = under-supplied)

`jobs_reachable` counts how many postings a candidate already covers at
>= `threshold` of the required skills - a market-level view of employability
that the single-job score cannot give.
"""

from collections import Counter


def parse_skills(value):
    return {s.strip().lower() for s in (value or "").split(";") if s.strip()}


def demand_by_skill(jobs):
    c = Counter()
    for j in jobs:
        c.update(parse_skills(j.get("skills_required")))
    n = len(jobs) or 1
    return [{"skill": s, "count": k, "percent": round(100 * k / n, 1)}
            for s, k in sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))]


def supply_by_skill(resumes):
    c = Counter()
    for r in resumes:
        c.update(parse_skills(r.get("skills")))
    n = len(resumes) or 1
    return {s: round(100 * k / n, 1) for s, k in c.items()}


def skill_gap_index(jobs, resumes, top_n=12):
    """Skills the market wants most relative to how many candidates have them."""
    supply = supply_by_skill(resumes)
    rows = []
    for d in demand_by_skill(jobs):
        sup = supply.get(d["skill"], 0.0)
        rows.append({"skill": d["skill"], "demand": d["percent"], "supply": sup,
                     "gap": round(d["percent"] - sup, 1)})
    rows.sort(key=lambda r: (-r["gap"], r["skill"]))
    return rows[:top_n]


def count_by(rows, field, top_n=10):
    c = Counter((r.get(field) or "Unknown").strip() for r in rows)
    return [{"label": k, "count": v} for k, v in
            sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[:top_n]]


def jobs_reachable(skills, jobs, threshold=0.8):
    """Number of postings whose required skills are covered >= threshold."""
    have = {s.lower() for s in skills}
    n = 0
    for j in jobs:
        need = parse_skills(j.get("skills_required"))
        if need and len(need & have) / len(need) >= threshold:
            n += 1
    return n


def summary(jobs, resumes):
    return {
        "n_jobs": len(jobs), "n_resumes": len(resumes),
        "n_skills_demanded": len(demand_by_skill(jobs)),
        "top_demand": demand_by_skill(jobs)[:12],
        "gap": skill_gap_index(jobs, resumes),
        "locations": count_by(jobs, "location"),
        "roles": count_by(jobs, "job_role"),
    }
