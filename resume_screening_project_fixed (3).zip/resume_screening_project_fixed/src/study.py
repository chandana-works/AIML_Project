"""
User-study support: blinded baseline-vs-full comparison
-------------------------------------------------------
For each study pair the participant sees two outputs labelled A and B.
Which one is the baseline (score only) and which is the full system
(score + gaps + learning path) is randomised per pair and recorded, so the
participant cannot tell and position bias can be checked afterwards.

Responses are appended to data/study_responses.csv (one row per pair).
Ratings are stored un-scrambled (baseline_* vs full_*) for analysis.
"""

import csv
import os
import random
import threading
from datetime import datetime, timezone

FIELDS = [
    "timestamp", "participant_id", "pair_index", "resume_id", "job_id",
    "full_position", "baseline_useful", "baseline_actionable",
    "full_useful", "full_actionable", "preference", "would_help",
]
PREFERENCES = {"full", "baseline", "equal"}
HELP_CHOICES = {"yes", "maybe", "no"}
_LOCK = threading.Lock()


def pick_pairs(rng, resumes, jobs, score_fn, n_pairs=6, max_draws=400):
    """Random resume-job pairs with >=1 missing skill and distinct jobs."""
    pairs, used_jobs = [], set()
    for _ in range(max_draws):
        if len(pairs) >= n_pairs:
            break
        r, j = rng.choice(resumes), rng.choice(jobs)
        if j["job_id"] in used_jobs:
            continue
        _pct, scores, _full = score_fn(r, j)
        if set(scores["job_skills"]) - set(scores["resume_skills"]):
            pairs.append({"resume_id": r["resume_id"], "job_id": j["job_id"],
                          "full_position": rng.choice(["A", "B"])})
            used_jobs.add(j["job_id"])
    return pairs


def _rating(form, key):
    try:
        v = int(form.get(key, ""))
    except ValueError:
        raise ValueError("Please rate every item from 1 to 5.")
    if not 1 <= v <= 5:
        raise ValueError("Ratings must be between 1 and 5.")
    return v


def parse_response(form, pair):
    """Validate one submitted form and un-scramble A/B into baseline/full."""
    pos = pair["full_position"]
    base_pos = "B" if pos == "A" else "A"
    pref_raw = form.get("preference", "")
    if pref_raw not in {"A", "B", "equal"}:
        raise ValueError("Please choose which output you prefer.")
    preference = "equal" if pref_raw == "equal" else ("full" if pref_raw == pos else "baseline")
    would_help = form.get("would_help", "")
    if would_help not in HELP_CHOICES:
        raise ValueError("Please answer whether this would help you improve your application.")
    return {
        "full_position": pos,
        "baseline_useful": _rating(form, f"useful_{base_pos}"),
        "baseline_actionable": _rating(form, f"actionable_{base_pos}"),
        "full_useful": _rating(form, f"useful_{pos}"),
        "full_actionable": _rating(form, f"actionable_{pos}"),
        "preference": preference,
        "would_help": would_help,
    }


def append_response(path, participant_id, pair_index, pair, parsed):
    row = {"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "participant_id": participant_id, "pair_index": pair_index,
           "resume_id": pair["resume_id"], "job_id": pair["job_id"], **parsed}
    with _LOCK:
        new = not os.path.exists(path) or os.path.getsize(path) == 0
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=FIELDS)
            if new:
                w.writeheader()
            w.writerow(row)
    return row


def new_participant_id():
    return "P" + "%06x" % random.SystemRandom().randrange(16 ** 6)
