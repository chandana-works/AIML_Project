
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
COURSE_FILE = DATA_DIR / "course_catalog.csv"

# Fallback resources if the catalog has no matching course.
FALLBACK_COURSES = {
    "python": {
        "course_name": "Python Tutorial",
        "provider": "Python Official Documentation",
        "course_url": "https://docs.python.org/3/tutorial/",
        "difficulty": "Beginner",
        "cost": "Free",
        "project_idea": "Build a command-line task manager."
    },
    "sql": {
        "course_name": "Interactive SQL Lessons",
        "provider": "SQLBolt",
        "course_url": "https://sqlbolt.com/",
        "difficulty": "Beginner",
        "cost": "Free",
        "project_idea": "Create a database and practise queries."
    },
    "git": {
        "course_name": "Getting Started with GitHub",
        "provider": "GitHub Docs",
        "course_url": "https://docs.github.com/en/get-started",
        "difficulty": "Beginner",
        "cost": "Free",
        "project_idea": "Publish a project with a README."
    },
    "rest api": {
        "course_name": "FastAPI Tutorial",
        "provider": "FastAPI",
        "course_url": "https://fastapi.tiangolo.com/tutorial/",
        "difficulty": "Beginner",
        "cost": "Free",
        "project_idea": "Build an API for job listings."
    },
}


def recommend_courses(missing_skills, limit_per_skill=3):
    """Return learning resources for each skill gap."""
    recommendations = {}

    if COURSE_FILE.exists():
        try:
            catalog = pd.read_csv(COURSE_FILE).fillna("")
        except (OSError, pd.errors.ParserError):
            catalog = pd.DataFrame()
    else:
        catalog = pd.DataFrame()

    # Normalize column names for matching.
    catalog.columns = [
        str(column).strip().lower() for column in catalog.columns
    ]

    skill_column = next(
        (column for column in ("skill_name", "skill", "skills")
         if column in catalog.columns),
        None
    )

    for skill in missing_skills:
        key = str(skill).strip().lower()
        matches = []

        if skill_column:
            matches = catalog[
                catalog[skill_column].astype(str).str.lower().str.contains(
                    key, regex=False, na=False
                )
            ].head(limit_per_skill).to_dict("records")

        if matches:
            recommendations[skill] = matches
        else:
            fallback = FALLBACK_COURSES.get(key)
            recommendations[skill] = [fallback] if fallback else []

    return recommendations
