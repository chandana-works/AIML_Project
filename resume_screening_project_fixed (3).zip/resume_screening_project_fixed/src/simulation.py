"""
Skill-Gap Closure Simulation  ("what if I learn X and Y?")
----------------------------------------------------------
Re-scores the candidate after hypothetically acquiring missing skills. Only
the skill-match feature changes:

    skill_match' = (|matched| + |learned|) / |required|

CGPA / PUC are unchanged, and the TF-IDF similarity is not an input of the
final score, so the projection is just the trained model re-evaluated.
"""


def _score_with(model, features, matched, learned, total):
    f = list(features)
    f[0] = (matched + learned) / total if total else 0.0
    return 100.0 * model.predict(f)


def simulate_closure(model, features, resume_skills, job_skills, ordered_skills):
    """Returns
        base            : current score in %
        steps           : cumulative score after learning each skill in order
        marginal        : score gain of learning each skill on its own
        ceiling         : score if every missing skill were learned
    """
    total = len(job_skills)
    matched = len(set(resume_skills) & set(job_skills))
    base = _score_with(model, features, matched, 0, total)

    steps, prev = [], base
    for i, skill in enumerate(ordered_skills, start=1):
        score = _score_with(model, features, matched, i, total)
        steps.append({"skill": skill, "n_learned": i, "score": score,
                      "delta": score - prev, "total_gain": score - base})
        prev = score

    one = _score_with(model, features, matched, 1, total) - base if total else 0.0
    marginal = {s: one for s in ordered_skills}
    return {
        "base": base,
        "steps": steps,
        "marginal": marginal,
        "ceiling": steps[-1]["score"] if steps else base,
        "matched": matched,
        "total": total,
    }
