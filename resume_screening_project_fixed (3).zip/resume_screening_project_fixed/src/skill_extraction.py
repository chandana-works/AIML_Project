"""
Skill Extraction Module
------------------------
Plain NER (e.g. spaCy's default model) is trained to recognize generic
entities like PERSON, ORG, DATE - it has no notion of "skill" as a category,
so it is not reliable for this task.

Instead we extract skills two ways:
  1. Phrase Matching  - match resume/job text against a curated skills
     taxonomy (with known aliases/synonyms), catching exact and
     near-exact mentions.
  2. Fuzzy Matching   - catch minor typos/variants using difflib's
     sequence-matching (no external NLP model required).

A semantic layer (Sentence-BERT + cosine similarity) is the natural next
step for catching skills phrased completely differently (e.g. "built ML
models" -> "machine learning"). That requires downloading a pretrained
transformer model, which needs internet access. The integration point is
included at the bottom of this file, commented out, ready to enable on a
machine with internet access.
"""

import csv
import re
import difflib


def load_skills_taxonomy(path):
    """
    Loads the skills taxonomy CSV into a lookup dict:
        alias_text -> canonical_skill_name
    Every skill maps to itself, plus each of its aliases maps to the
    same canonical name.
    """
    taxonomy = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            canonical = row["skill"].strip().lower()
            taxonomy[canonical] = canonical
            aliases = row.get("aliases", "")
            if aliases:
                for alias in aliases.split("|"):
                    alias = alias.strip().lower()
                    if alias:
                        taxonomy[alias] = canonical
    return taxonomy


def normalize_text(text):
    """Lowercase and strip punctuation noise, keep alphanumerics/spaces/+/#/."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\+\#\.\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_skills(text, taxonomy, fuzzy_cutoff=0.88):
    """
    Extracts the set of canonical skills mentioned in `text`.

    Step 1 (Phrase Matching): check every taxonomy phrase (skill name or
    alias) as a substring of the normalized text. This handles multi-word
    skills like "machine learning" or "power bi" correctly.

    Step 2 (Fuzzy Matching): for single tokens in the text that didn't
    match directly, check for close matches against taxonomy keys (catches
    typos like "pythom" -> "python").
    """
    norm_text = normalize_text(text)
    found = set()

    # Step 1: phrase matching (longer phrases first, so "machine learning"
    # is matched before trying to match "machine" or "learning" alone)
    phrases = sorted(taxonomy.keys(), key=len, reverse=True)
    for phrase in phrases:
        pattern = r"\b" + re.escape(phrase) + r"\b"
        if re.search(pattern, norm_text):
            found.add(taxonomy[phrase])

    # Step 2: fuzzy matching on individual tokens for anything not caught above
    tokens = norm_text.split()
    taxonomy_keys = list(taxonomy.keys())
    for token in tokens:
        if len(token) < 3:
            continue
        close = difflib.get_close_matches(token, taxonomy_keys, n=1, cutoff=fuzzy_cutoff)
        if close:
            found.add(taxonomy[close[0]])

    return found


def parse_semicolon_list(value):
    """Helper for resume/job rows where skills are stored as 'a;b;c'."""
    if not value:
        return set()
    return {v.strip().lower() for v in value.split(";") if v.strip()}


# ---------------------------------------------------------------------------
# OPTIONAL: Semantic matching with Sentence-BERT (requires internet access
# to download the pretrained model - not available in this build environment).
# Uncomment and run `pip install sentence-transformers` on a machine with
# internet access to enable this as an additional matching layer.
# ---------------------------------------------------------------------------
#
# from sentence_transformers import SentenceTransformer, util
#
# _model = SentenceTransformer("all-MiniLM-L6-v2")
#
# def semantic_skill_match(resume_phrase, job_phrase, threshold=0.6):
#     """Returns True if two differently-worded phrases likely mean the
#     same skill, e.g. 'built ML models' vs 'machine learning'."""
#     emb = _model.encode([resume_phrase, job_phrase])
#     score = util.cos_sim(emb[0], emb[1]).item()
#     return score >= threshold, score
