"""
Main Demo Script
------------------
Run with:   python3 main.py            (default small sample data)
            DATASET=scaled python3 main.py   (the scaled dataset)

1. Trains the scoring model with Gradient Descent (calculus component):
   logistic regression (default) and, for comparison, the original linear/MSE.
2. Loads job postings, resumes, taxonomy, course catalog, skill metadata.
3. For a few resume-job pairs prints: baseline output (score only) vs the full
   output = score + feature explanation + prioritised learning path +
   what-if simulation.
"""

import csv
import os
from src import (skill_extraction, skill_gap, weight_optimizer, pipeline,
                 explain, skill_priority, simulation)

DATASET = os.environ.get("DATASET", "")
DATA_DIR = os.path.join("data", DATASET) if DATASET else "data"


def load_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def main():
    print("=" * 70)
    print("STEP 1: Training the scoring model with Gradient Descent")
    print("=" * 70)
    X, y = weight_optimizer.load_training_data(f"{DATA_DIR}/historical_hiring_data.csv")

    print("\n[Logistic regression - cross-entropy loss]  (default model)")
    model = weight_optimizer.fit_model(X, y, kind="logistic")
    w = model.weights
    print(f"  weights -> skill: {w[0]:.3f}, cgpa: {w[1]:.3f}, puc: {w[2]:.3f}, "
          f"bias: {model.bias:.3f}")
    print(f"  L2 strength (CV-selected): {model.l2}, loss {model.loss_history[0]:.4f} -> {model.loss_history[-1]:.4f} "
          f"over {len(model.loss_history)} epochs ({model.n_train} training rows)")

    print("\n[Linear model - MSE loss]  (original version, for comparison)")
    lin = weight_optimizer.fit_model(X, y, kind="linear")
    print(f"  weights -> {[round(v, 3) for v in lin.weights]}, bias {lin.bias:.3f}; "
          f"loss {lin.loss_history[0]:.4f} -> {lin.loss_history[-1]:.4f}")

    print("\n" + "=" * 70)
    print("STEP 2: Loading data")
    print("=" * 70)
    taxonomy = skill_extraction.load_skills_taxonomy(f"{DATA_DIR}/skills_taxonomy.csv")
    jobs = load_csv(f"{DATA_DIR}/job_postings.csv")
    resumes = load_csv(f"{DATA_DIR}/resumes.csv")
    catalog = skill_gap.load_course_catalog(f"{DATA_DIR}/course_catalog.csv")
    meta = skill_priority.load_skill_meta(f"{DATA_DIR}/skill_meta.csv")
    stats = skill_priority.build_corpus_stats(jobs)
    print(f"Loaded {len(jobs)} jobs, {len(resumes)} resumes, "
          f"{len(taxonomy)} taxonomy entries, {len(catalog)} courses.\n")

    print("=" * 70)
    print("STEP 3: Running the pipeline on sample resume-job pairs")
    print("=" * 70)
    jobs_by_id = {j["job_id"]: j for j in jobs}
    resumes_by_id = {r["resume_id"]: r for r in resumes}
    pairs = [("R003", "J003"), ("R001", "J010"), ("R010", "J001")]
    if DATASET:  # scaled data uses different ids; pick the first few
        pairs = [(resumes[i]["resume_id"], jobs[i]["job_id"]) for i in (0, 1, 2)]

    for resume_id, job_id in pairs:
        resume_row, job_row = resumes_by_id[resume_id], jobs_by_id[job_id]
        scores = pipeline.score_pair(resume_row, job_row, model, taxonomy)
        baseline = pipeline.generate_baseline_output(scores)
        full = pipeline.generate_full_output(scores, catalog)

        print(f"\n--- {resume_row['candidate_name']} ({resume_id}) vs "
              f"{job_row['job_role']} at {job_row['company']} ({job_id}) ---")
        print(f"  [BASELINE]  Match Score: {baseline['match_score_percent']}%")
        print(f"  [FULL]      Match Score: {full['match_score_percent']}%")

        ex = explain.explain_score(model, scores["features"])
        print(f"\n  Why this score? (average applicant = {ex['baseline']:.1f}%)")
        for it in ex["items"]:
            print(f"    {it['label']:<12} {it['contribution']:+6.1f} pts "
                  f"(value {it['value']:.2f} vs avg {it['average']:.2f})")

        path = skill_priority.build_learning_path(
            full["missing_skills"], scores["resume_skills"], stats, meta, catalog)
        if not path["steps"]:
            print("\n  Missing skills: none - candidate covers every required skill")
            continue
        print(f"\n  Prioritised learning path (~{path['total_hours']} h, "
              f"~{path['total_weeks']} weeks at {path['hours_per_week']} h/week):")
        for st in path["steps"]:
            pre = f"  needs: {', '.join(st['prerequisites'])}" if st["prerequisites"] else ""
            print(f"    {st['rank']}. {st['skill']:<24} priority {st['priority']:.2f} | "
                  f"{st['hours']:>3} h{pre}")

        sim = simulation.simulate_closure(
            model, scores["features"], scores["resume_skills"],
            scores["job_skills"], [s["skill"] for s in path["steps"]])
        print(f"\n  What-if simulation (current {sim['base']:.1f}%):")
        for st in sim["steps"]:
            print(f"    after learning {st['skill']:<24} -> {st['score']:.1f}% "
                  f"({st['delta']:+.1f})")
        print("-" * 60)


if __name__ == "__main__":
    main()
