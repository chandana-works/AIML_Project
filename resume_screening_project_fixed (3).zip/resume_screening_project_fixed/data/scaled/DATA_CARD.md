# Data card - scaled

- Provenance: SYNTHETIC jobs/resumes (role templates + seeded RNG).
- Jobs: 70 | Resumes: 400 | Resume-job pairs: 4800
- Labels: SIMULATED recruiter (proxy) - NOT real hiring outcomes
- Positive rate: 943/4800 (19.6%)
- Seed: 42
- Top roles: {'Data Analyst': 5, 'Python Developer': 5, 'Machine Learning Engineer': 5, 'Software Engineer': 5, 'Backend Developer': 5}

Do not report accuracy on proxy-labelled data as real-world performance.
