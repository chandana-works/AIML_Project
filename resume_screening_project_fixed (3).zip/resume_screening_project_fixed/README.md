# Localized Skill-Gap-Aware Resume Screening with Learning Path Recommendations

CS2227 AI and ML Project | RV University

> **Data status (read first).** The bundled dataset (`data/scaled/`: 70 jobs, 400 resumes, 4,800 pairs) is **synthetic**, and its
> labels come from a **simulated recruiter**, not real hiring decisions. All accuracy, precision and recall figures below measure
> agreement with that simulator, not real-world performance (see `data/scaled/DATA_CARD.md`).

## Problem Statement

Conventional resume screening systems only tell a candidate whether they
match a job or not, giving no insight into why or what to improve.
Existing systems that do offer skill-gap feedback are built on generic,
non-Indian job market data and are rarely tested to see if they actually
help candidates. This project addresses both gaps by building a
skill-gap detection and course recommendation system tailored to the
Indian tech job market, evaluated through a real comparative study
against a baseline score-only system.

## Folder Structure

```
resume_screening_project/
├── app.py                          Flask web app (upload -> review -> insights, /model page)
├── features.py                     NEW: /recommend, /insights, /study, /annotate routes
├── paper/                          NEW: checklist, study protocol, paper template, references to verify
├── main.py                         Terminal demo of the full pipeline
├── requirements.txt
├── data/
│   ├── job_postings.csv, resumes.csv, ...    Original small sample (12 jobs / 12 resumes)
│   ├── skill_meta.csv              NEW: learning hours + prerequisite graph per skill
│   └── scaled/                     NEW: 70 jobs / 400 resumes / 4,800 labelled pairs + DATA_CARD.md
├── src/
│   ├── job_recommender.py          NEW: rank all jobs for one candidate
│   ├── market_insights.py          NEW: skill demand vs supply
│   ├── annotation.py               NEW: annotation store + kappa
│   ├── semantic.py                 NEW: optional SBERT
│   ├── study.py                    NEW: blinded A/B study logic
│   ├── skill_extraction.py         Phrase + Fuzzy matching
│   ├── matching.py                 TF-IDF + Cosine Similarity, skill overlap
│   ├── academic_score.py           Min-Max normalization
│   ├── weight_optimizer.py         Gradient Descent: linear (MSE) + NEW logistic (cross-entropy)
│   ├── explain.py                  NEW: exact Shapley values per feature
│   ├── skill_priority.py           NEW: prerequisite-aware, demand-ranked learning path + hours
│   ├── simulation.py               NEW: "what if I learn X and Y?" score projection
│   ├── skill_gap.py, pipeline.py, config.py
├── scripts/
│   └── build_scaled_dataset.py     NEW: synthetic generator + Kaggle (Naukri / Resume Dataset) adapters
├── evaluate/
│   ├── make_annotation_set.py      NEW: stratified pairs for annotation
│   ├── analyze_annotations.py      NEW: kappa + gold labels
│   ├── evaluate_on_human_labels.py NEW: scorer vs human labels
│   ├── analyze_study.py            NEW: statistics for the user study
│   ├── evaluate_learning_paths.py  NEW: priority vs baseline orders
│   ├── compare_models.py           NEW: baselines, models, ablations, CV, NDCG, Wilcoxon
│   ├── results/                    NEW: generated comparison tables (.csv / .md)
│   └── generate_study_pairs.py     Builds baseline-vs-full pairs for the user study
├── tests/test_new_modules.py       NEW: unit tests (python -m unittest discover -s tests)
├── templates/, static/             Redesigned UI
└── README.md
```

## How to Run

```bash
pip install -r requirements.txt
python app.py                                  # web app on the scaled dataset
SHOW_MODEL_PAGE=1 python app.py                # also enable the /model research page (hidden by default)
DATASET=base python app.py                     # the original 12-job sample
MODEL_TYPE=linear python app.py                # original linear/MSE model instead of logistic
python main.py                                 # terminal demo
python -m unittest discover -s tests -v        # tests
python evaluate/evaluate_learning_paths.py     # learning-path experiment
python evaluate/analyze_study.py               # after collecting /study responses
python evaluate/compare_models.py --data-dir data/scaled   # experiments table
python scripts/build_scaled_dataset.py --mode synthetic    # regenerate scaled data
```

Using the real public datasets (not bundled; no internet in the build environment):

```bash
python scripts/build_scaled_dataset.py --mode kaggle \
    --jobs-csv naukri_data_science_jobs.csv --resumes-csv UpdatedResumeDataSet.csv \
    --out data/kaggle --label none          # then annotate `suitable` by hand
DATASET=kaggle python app.py
```

## New in this version

| # | Feature | Where | Notes |
|---|---|---|---|
| 5 | Explainability | `src/explain.py`, "Why this score?" card | Exact interventional Shapley values (3 features -> all 8 subsets). base + contributions = score. |
| 6 | Prioritised learning path | `src/skill_priority.py`, `data/skill_meta.csv` | Topological order over a prerequisite graph; ties by demand / unlock / co-occurrence affinity / quick-win. Hours are editable assumptions. |
| 7 | Logistic regression | `src/weight_optimizer.py`, `evaluate/compare_models.py` | Hand-written gradient descent, cross-entropy + L2; features z-scored internally; L2 chosen by CV (one-SE rule). Verified against scikit-learn. |
| - | Course links | `src/skill_gap.py` | Every missing skill gets a link: curated catalog row, or auto-generated Coursera + Udemy search links. |
| 8 | What-if simulation | `src/simulation.py`, results page | Server-side table + live browser simulator. |
| 9 | Scaled data | `scripts/build_scaled_dataset.py`, `data/scaled/` | Synthetic generator + Kaggle adapters. |

## Market-level feature

| Feature | Where | Notes |
|---|---|---|
| Job recommendations | `/recommend`, `src/job_recommender.py` | Scores one candidate (sample resume or typed skills) against every job with the trained model; lists the missing skills per job and the skills that would unlock the most jobs. Extends skill-gap feedback from one job to the whole market. |

## Research tooling

| Feature | Where | Notes |
|---|---|---|
| Blinded user study | `/study`, `src/study.py` | Participants see baseline vs full output as randomly ordered "A"/"B" for 6 pairs and rate usefulness, actionability, preference. Anonymous; saved to `data/study_responses.csv`. |
| Study analysis | `evaluate/analyze_study.py` | Participant-level Wilcoxon, effect size, bootstrap CI, preference binomial test, position-bias check. Writes `evaluate/results/study_results.md`. |
| Market insights | `/insights`, `src/market_insights.py` | Skill demand vs candidate supply, biggest gaps, jobs by city/role - the "localized" evidence. |
| Learning-path evaluation | `evaluate/evaluate_learning_paths.py` | Compares priority order vs demand-only / quickest / random on "market reach" (postings covered at >= 80%). Output in `evaluate/results/learning_path_eval_*.md`. |

Run the study: start the app, share `/study` with 15-20 people, then `python evaluate/analyze_study.py`.

**Honest finding (scaled synthetic data, k = 3):** the priority order opened up about 3.95 extra postings versus 3.92 for random - not a meaningful or significant difference. Its measurable value is *prerequisite-correct ordering* (e.g. SQL before Power BI) and the hour estimates, not a larger market reach. Report it that way; do not claim the priority weights are optimal.

## Making it submission-ready (tooling for the missing evidence)

The project cannot supply real data, human labels or study responses by itself; these tools make collecting them quick.
Follow `paper/SUBMISSION_CHECKLIST.md`.

| Need | Tool |
|---|---|
| Human gold labels | `evaluate/make_annotation_set.py`, `/annotate` (enable with `SHOW_ANNOTATE_PAGE=1`), `evaluate/analyze_annotations.py` (Cohen's kappa) |
| Honest scorer evaluation | `evaluate/evaluate_on_human_labels.py` (AUC + bootstrap CIs vs keyword / TF-IDF / fixed-weight / optional SBERT; also kappa of the synthetic labels vs humans) |
| User study | `/study`, `paper/STUDY_PROTOCOL.md`, `evaluate/analyze_study.py` |
| Optional SBERT arm | `src/semantic.py`, `--sbert` flag (needs `pip install sentence-transformers` and internet once; tested only with a stub encoder) |
| Writing | `paper/PAPER_TEMPLATE.md`, `paper/REFERENCES_TO_VERIFY.md` (verify every reference yourself) |

## Results at a glance (scaled synthetic data, simulated labels)

Accuracy, precision and recall are always quoted together. Mean +- std over 5-fold CV x 3 repeats
(`evaluate/results/model_comparison_scaled.md`; 4,800 pairs, 19.6% positive).

| Model | Accuracy | Precision | Recall | F1 | AUC |
|---|---|---|---|---|---|
| **Logistic GD (ours)** | **0.920** | **0.823** | **0.754** | 0.787 | 0.966 |
| Keyword overlap only | 0.903 | 0.747 | 0.767 | 0.757 | 0.950 |
| Fixed weights 0.5/0.3/0.2 | 0.912 | 0.756 | 0.818 | 0.785 | 0.964 |
| Linear GD (MSE), original | 0.913 | 0.821 | 0.713 | 0.763 | 0.960 |
| sklearn LogisticRegression | 0.919 | 0.819 | 0.759 | 0.787 | 0.965 |

How to read this honestly:
* Our model matches sklearn's logistic regression (as it should) and is only slightly ahead of the hand-set fixed weights
  (AUC 0.966 vs 0.964). The gap is statistically detectable on 4,800 pairs but small in practice; the fixed weights even have higher recall.
* On the small 144-pair base file, keyword overlap alone is as good as the trained model (F1 about 0.96) - the labels there are rule-derived.
* Learning path: the priority order gives no meaningful gain over random in market reach (3.95 vs 3.92 extra postings, p = 0.07).
  Its value is prerequisite-correct ordering and hour estimates (`evaluate/results/learning_path_eval_scaled.md`).

## IMPORTANT limitations (state these in the paper)

* **Labels are not real hiring outcomes.** `data/labeled_resume_job_pairs.csv` is rule-derived
  (CGPA >= minimum and >= 50% skill overlap). `data/scaled/` labels come from a *simulated recruiter*
  (noisy utility with experience-fit and a CGPA cut-off). Metrics on these files measure agreement
  with that rule/simulator. On the rule-labelled file a keyword-overlap baseline already scores
  F1 ~ 0.96, which is expected and shows why human or real-outcome labels are needed.
* The Kaggle adapters were tested only on small mock files in the same format (the real datasets
  could not be downloaded here). Column names are auto-detected; override with `--job-cols` / `--resume-cols`.
* Learning hours and the prerequisite graph are author-curated estimates, and the priority
  weights (0.4 / 0.3 / 0.2 / 0.1) are heuristics.
* The final score is an estimated probability of being shortlisted by the trained model; for the
  small hand-made hiring file it is steep (scores near 0% / 100%).
* SBERT semantic matching is still not enabled (needs a model download).

## Algorithms Used (by pipeline stage)

| Stage | Algorithm | What it does |
|---|---|---|
| Skill Extraction | Phrase Matching + Fuzzy Matching | Matches resume/job text against a curated skills taxonomy; catches exact mentions and minor typos. Plain NER isn't trained to recognize "skill" as an entity type, so this replaces it. |
| Overall Match Score | TF-IDF + Cosine Similarity | Converts resume/job text into vectors and measures similarity, capturing overall contextual fit. |
| Skill Match Score | Skill Overlap Ratio | Fraction of the job's required skills the candidate already has. |
| Academic Score | Min-Max Normalization | Scales CGPA (0-10) and PUC/degree percentage (0-100) onto the same 0-1 range. |
| Final Scoring | Gradient Descent (Logistic Regression; linear/MSE kept for comparison) | Learns weights for skill score, CGPA and PUC from historical hiring data by minimizing cross-entropy via its partial derivatives. **This is the calculus component.** |
| Skill Gap Detection | Set Difference | Required skills minus possessed skills = what's missing. |
| Explanation | Exact Shapley values | Per-feature contribution to the score vs a typical applicant. |
| Learning Path | Topological sort + demand/co-occurrence ranking | Orders missing skills, prerequisites first, with hour estimates. |
| What-if | Model re-evaluation | Projected score after learning chosen skills. |

## The Calculus Component (Gradient Descent), in Plain Terms

Instead of guessing fixed weights for combining skill score, CGPA, and
PUC percentage, `src/weight_optimizer.py` learns them from historical
hiring outcomes:

1. **Loss function**: cross-entropy (logistic regression, default) plus an L2 penalty
   chosen by cross-validation. The original Mean Squared Error (linear) model is kept
   for comparison (`MODEL_TYPE=linear`).
2. **Gradient**: the partial derivative of that loss with respect to each
   weight - tells us which direction to adjust each weight to reduce
   error.
3. **Update rule**: `weight = weight - learning_rate * gradient`, repeated
   for many epochs on z-scored features.

Run `main.py` and watch the loss in Step 1 decrease - that's the gradient descent optimization happening live.

## Note on Semantic Matching (SBERT)

The full plan includes Sentence-BERT (SBERT) + Cosine Similarity to catch
skills phrased completely differently (e.g. "built ML models" ~=
"machine learning"). This requires downloading a pretrained transformer
model, which needs internet access unavailable in the environment this
was built in. The integration code is included, commented out, at the
bottom of `src/skill_extraction.py` - uncomment it and run
`pip install sentence-transformers` on a machine with internet access to
enable it. Everything else in this project runs fully offline as-is.

## Datasets

The included CSVs are a small representative sample (12 jobs, 12 resumes)
standing in for the full dataset. For the real project, swap in:
- **Job postings**: "12000 Data Science Jobs In India - Naukri.com" (Kaggle)
- **Resumes**: Any Kaggle "Resume Dataset" categorized by job role

Keep the same column structure as `data/job_postings.csv` and
`data/resumes.csv` and everything else works unchanged.

## Comparative Evaluation Plan

`evaluate/generate_study_pairs.py` produces `evaluate/study_pairs.csv`
containing, for each resume-job pair, both the baseline output (score
only) and the full output (score + missing skills + recommendations).

**Study design**: show ~15-20 respondents both versions (unlabeled, so
they don't know which is "ours") for several pairs, and ask:
- Which output is more useful?
- How actionable does it feel (1-5)?
- Would this help you improve your application?

Compare the ratings to show whether the skill-gap + recommendation output
is genuinely more useful than a plain match score - the evaluation step
missing from most existing published work in this space.
