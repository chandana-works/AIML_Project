"""
Extra features, registered onto the existing Flask app:

  /recommend      Pick a resume (or type skills) -> best-fit jobs + top skills to learn
  /insights       Job-market demand vs candidate supply (localization evidence)
  /annotate       (SHOW_ANNOTATE_PAGE=1 only) two-annotator gold-label tool
  /study          Blinded baseline-vs-full user study; responses -> data/study_responses.csv

Wired in from app.py with:   features.register_features(app, {...})
"""

import random

from flask import Blueprint, abort, redirect, render_template, request, session, url_for

from src import (annotation, job_recommender, market_insights, simulation,
                 skill_priority, study)


def register_features(app, ctx):
    bp = Blueprint("features", __name__)
    jobs, resumes = ctx["jobs"], ctx["resumes"]
    jobs_by_id = {j["job_id"]: j for j in jobs}
    resumes_by_id = {r["resume_id"]: r for r in resumes}

    def score_fn(resume_row, job_row):
        from src import pipeline
        scores = pipeline.score_pair(resume_row, job_row, ctx["model"], ctx["taxonomy"])
        full = pipeline.generate_full_output(scores, ctx["catalog"])
        return float(full["match_score_percent"]), scores, full

    def manual_row(form):
        skills = [s.strip() for s in form.get("skills", "").replace("\n", ",").split(",") if s.strip()]
        # If pipeline.score_pair needs extra resume columns, add them here.
        return {
            "resume_id": "MANUAL", "candidate_name": "You", "email": "",
            "target_role": form.get("target_role", "").strip(),
            "skills": ";".join(skills),
            "cgpa": str(min(max(float(form.get("cgpa") or 0), 0), 10)),
            "puc_percentage": str(min(max(float(form.get("puc_percentage") or 0), 0), 100)),
        }

    @bp.route("/recommend", methods=["GET", "POST"])
    def recommend():
        sample = resumes[:60]
        if request.method == "GET":
            return render_template("recommend.html", resumes=sample)
        try:
            if request.form.get("resume_id") in resumes_by_id:
                row = resumes_by_id[request.form["resume_id"]]
            elif request.form.get("skills", "").strip():
                row = manual_row(request.form)
            else:
                raise ValueError("Choose a sample resume or enter your skills.")
        except ValueError as exc:
            return render_template("recommend.html", resumes=sample, error=str(exc)), 400
        recs = job_recommender.recommend_jobs(row, jobs, score_fn, top_n=10)
        have = [s for s in row["skills"].split(";") if s.strip()]
        demand = job_recommender.skill_demand_summary(jobs, have, top_n=8)
        return render_template("recommend.html", resumes=sample, row=row, recs=recs, demand=demand)

    # ------------------------------------------------------------------
    # Market insights
    # ------------------------------------------------------------------
    @bp.route("/insights")
    def insights():
        return render_template("insights.html", s=market_insights.summary(jobs, resumes))

    # ------------------------------------------------------------------
    # Blinded user study (baseline vs full output)
    # ------------------------------------------------------------------
    study_file = ctx.get("study_file", "data/study_responses.csv")
    N_STUDY_PAIRS = 6

    def build_study_output(pair):
        resume, job = resumes_by_id[pair["resume_id"]], jobs_by_id[pair["job_id"]]
        _pct, scores, full = score_fn(resume, job)
        baseline = {"kind": "baseline", "score": full["match_score_percent"]}
        path = skill_priority.build_learning_path(
            full["missing_skills"], scores["resume_skills"], ctx["corpus_stats"],
            ctx["skill_meta"], full["course_recommendations"])
        sim = simulation.simulate_closure(
            ctx["model"], scores["features"], scores["resume_skills"],
            scores["job_skills"], [st["skill"] for st in path["steps"]])
        fuller = {"kind": "full", "score": full["match_score_percent"],
                  "missing": full["missing_skills"], "steps": path["steps"],
                  "total_hours": path["total_hours"], "total_weeks": path["total_weeks"],
                  "hours_per_week": path.get("hours_per_week"),
                  "projected": round(sim["ceiling"], 1)}
        return baseline, fuller

    @bp.route("/study")
    def study_intro():
        return render_template("study.html", stage="intro", n_pairs=N_STUDY_PAIRS)

    @bp.route("/study/start", methods=["POST"])
    def study_start():
        rng = random.Random()
        pairs = study.pick_pairs(rng, resumes, jobs, score_fn, n_pairs=N_STUDY_PAIRS)
        if not pairs:
            return render_template("study.html", stage="intro", n_pairs=N_STUDY_PAIRS,
                                   error="Could not build study pairs from this dataset."), 500
        session["study"] = {"pid": study.new_participant_id(), "pairs": pairs, "answered": []}
        return redirect(url_for("features.study_pair", n=1))

    @bp.route("/study/<int:n>", methods=["GET", "POST"])
    def study_pair(n):
        st = session.get("study")
        if not st or not 1 <= n <= len(st["pairs"]):
            return redirect(url_for("features.study_intro"))
        pair = st["pairs"][n - 1]
        if request.method == "POST":
            if n in st["answered"]:
                return redirect(url_for("features.study_pair", n=n + 1) if n < len(st["pairs"])
                                else url_for("features.study_done"))
            try:
                parsed = study.parse_response(request.form, pair)
            except ValueError as exc:
                return _render_study_pair(n, st, pair, error=str(exc)), 400
            study.append_response(study_file, st["pid"], n, pair, parsed)
            st["answered"] = st["answered"] + [n]
            session["study"] = st
            if n < len(st["pairs"]):
                return redirect(url_for("features.study_pair", n=n + 1))
            return redirect(url_for("features.study_done"))
        return _render_study_pair(n, st, pair)

    def _render_study_pair(n, st, pair, error=None):
        baseline, fuller = build_study_output(pair)
        outputs = {pair["full_position"]: fuller,
                   ("B" if pair["full_position"] == "A" else "A"): baseline}
        job = jobs_by_id[pair["job_id"]]
        resume = resumes_by_id[pair["resume_id"]]
        return render_template("study.html", stage="pair", n=n, total=len(st["pairs"]),
                               outputs=outputs, job=job, resume=resume, error=error)

    @bp.route("/study/done")
    def study_done():
        st = session.get("study") or {}
        if len(st.get("answered", [])) < len(st.get("pairs", [1])):
            return redirect(url_for("features.study_intro"))
        return render_template("study.html", stage="done")

    # ------------------------------------------------------------------
    # Human annotation (gold labels) - research team only, off by default
    # ------------------------------------------------------------------
    pairs_file = ctx.get("annotation_pairs_file", "data/annotation_pairs.csv")
    annotations_file = ctx.get("annotations_file", "data/annotations.csv")

    def _annotate_guard():
        if not ctx.get("annotate_enabled"):
            abort(404)

    @bp.route("/annotate", methods=["GET", "POST"])
    def annotate_login():
        _annotate_guard()
        if request.method == "POST":
            name = request.form.get("annotator", "").strip()
            if not annotation.valid_annotator(name):
                return render_template("annotate.html", stage="login",
                                       error="Use 1-20 letters, digits, - or _ (e.g. A1)."), 400
            session["annotator"] = name
            return redirect(url_for("features.annotate_task"))
        return render_template("annotate.html", stage="login")

    @bp.route("/annotate/task", methods=["GET", "POST"])
    def annotate_task():
        _annotate_guard()
        who = session.get("annotator")
        pairs = annotation.load_pairs(pairs_file)
        if not who or not pairs:
            return redirect(url_for("features.annotate_login"))
        idx, pair = annotation.next_pair(pairs, annotation.load_annotations(annotations_file), who)
        if request.method == "POST":
            if pair is None or request.form.get("pair_id") != pair["pair_id"]:
                return redirect(url_for("features.annotate_task"))
            try:
                annotation.append_annotation(annotations_file, who, pair,
                                             request.form.get("label", ""), request.form.get("note", ""))
            except ValueError as exc:
                return render_template("annotate.html", stage="task", who=who, idx=idx, total=len(pairs),
                                       pair=pair, job=jobs_by_id[pair["job_id"]],
                                       resume=resumes_by_id[pair["resume_id"]], error=str(exc)), 400
            return redirect(url_for("features.annotate_task"))
        if pair is None:
            return render_template("annotate.html", stage="done", who=who, total=len(pairs))
        return render_template("annotate.html", stage="task", who=who, idx=idx, total=len(pairs),
                               pair=pair, job=jobs_by_id[pair["job_id"]],
                               resume=resumes_by_id[pair["resume_id"]])

    app.register_blueprint(bp)
