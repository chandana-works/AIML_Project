"""
Inter-annotator agreement and gold labels
=========================================
    python evaluate/analyze_annotations.py

Reads data/annotations.csv, reports Cohen's kappa and raw agreement between
the two annotators, writes
    data/human_labeled_pairs.csv                 (pairs both annotators agree on)
    evaluate/results/annotation_disagreements.csv (for discussion / adjudication)
    evaluate/results/annotation_summary.md
Report the kappa and the number of dropped (disagreed / unsure) pairs in the paper.
"""

import csv
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)
from src import annotation


def main():
    src = os.path.join(ROOT, "data", "annotations.csv")
    if not os.path.exists(src):
        sys.exit("data/annotations.csv not found - collect annotations at /annotate first.")
    res = annotation.analyse(annotation.load_annotations(src))
    if len(res["annotators"]) < 2:
        sys.exit("Need at least two annotators.")
    gold = res["gold"]
    n1 = sum(v["label"] for v in gold.values())
    k = res["kappa"]
    md = (f"# Annotation summary\n\nAnnotators: {', '.join(res['annotators'][:2])}\n\n"
          f"* Pairs compared (both gave Suitable/Not suitable): {res['n_compared']}\n"
          f"* Pairs with an 'unsure' label (excluded): {res['unsure']}\n"
          f"* Raw agreement: {100 * res['agreement']:.1f}%\n"
          f"* Cohen's kappa: {k:.3f} ({annotation.kappa_band(k)})\n"
          f"* Gold labels kept: {len(gold)} ({n1} suitable, {len(gold) - n1} not suitable)\n"
          f"* Disagreements: {len(res['disagreements'])}\n")
    os.makedirs(os.path.join(ROOT, "evaluate", "results"), exist_ok=True)
    with open(os.path.join(ROOT, "evaluate", "results", "annotation_summary.md"), "w") as f:
        f.write(md)
    with open(os.path.join(ROOT, "data", "human_labeled_pairs.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["pair_id", "resume_id", "job_id", "human_label"])
        for pid, v in sorted(gold.items()):
            w.writerow([pid, v["resume_id"], v["job_id"], v["label"]])
    if res["disagreements"]:
        keys = list(res["disagreements"][0].keys())
        with open(os.path.join(ROOT, "evaluate", "results", "annotation_disagreements.csv"),
                  "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(res["disagreements"])
    print(md)


if __name__ == "__main__":
    main()
