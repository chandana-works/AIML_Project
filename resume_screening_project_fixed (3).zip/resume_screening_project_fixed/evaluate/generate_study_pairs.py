"""
User Study Pair Generator
----------------------------
Generates baseline vs full-system outputs for several resume-job pairs,
and writes them to a CSV you can paste directly into a Google Form for
the comparative user study.

Run with:   python3 evaluate/generate_study_pairs.py
(run from the project root, not from inside evaluate/)

For the study: show each respondent the baseline_text, ask how useful/
actionable it feels (1-5), then show full_text for the same pair, ask the
same question. Don't label which is which when showing respondents.
"""

import csv
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import skill_extraction, skill_gap, weight_optimizer, pipeline

DATA_DIR = "data"
OUTPUT_PATH = "evaluate/study_pairs.csv"

# All resume-job pairs to include in the study (expand as needed)
PAIRS = [
    ("R001", "J010"), ("R002", "J002"), ("R003", "J003"), ("R004", "J004"),
    ("R005", "J005"), ("R006", "J006"), ("R007", "J007"), ("R008", "J008"),
    ("R009", "J009"), ("R010", "J001"), ("R011", "J011"), ("R012", "J012"),
]


def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def format_baseline(baseline):
    return f"Match Score: {baseline['match_score_percent']}%"


def format_full(full):
    lines = [f"Match Score: {full['match_score_percent']}%"]
    if full["missing_skills"]:
        lines.append(f"Missing Skills: {', '.join(full['missing_skills'])}")
        lines.append("Recommended Courses:")
        for skill, course in full["course_recommendations"].items():
            lines.append(f"  - {skill}: {course}")
    else:
        lines.append("Missing Skills: none")
    return " | ".join(lines)


def main():
    X, y = weight_optimizer.load_training_data(f"{DATA_DIR}/historical_hiring_data.csv")
    model = weight_optimizer.fit_model(X, y, kind="logistic")

    taxonomy = skill_extraction.load_skills_taxonomy(f"{DATA_DIR}/skills_taxonomy.csv")
    jobs = {j["job_id"]: j for j in load_csv(f"{DATA_DIR}/job_postings.csv")}
    resumes = {r["resume_id"]: r for r in load_csv(f"{DATA_DIR}/resumes.csv")}
    catalog = skill_gap.load_course_catalog(f"{DATA_DIR}/course_catalog.csv")

    rows = []
    for resume_id, job_id in PAIRS:
        resume_row = resumes[resume_id]
        job_row = jobs[job_id]
        scores = pipeline.score_pair(resume_row, job_row, model, taxonomy)
        baseline = pipeline.generate_baseline_output(scores)
        full = pipeline.generate_full_output(scores, catalog)

        rows.append({
            "pair_id": f"{resume_id}_{job_id}",
            "candidate": resume_row["candidate_name"],
            "job_role": job_row["job_role"],
            "company": job_row["company"],
            "baseline_text": format_baseline(baseline),
            "full_text": format_full(full),
        })

    with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} study pairs to {OUTPUT_PATH}")
    print("Next step: paste baseline_text / full_text pairs into your Google Form,")
    print("one pair per question, and ask respondents to rate usefulness 1-5 for each.")


if __name__ == "__main__":
    main()
