"""
Model comparison, baselines and ablations  (for the paper's experiments section)
================================================================================
    python evaluate/compare_models.py                      # data/labeled_resume_job_pairs.csv
    python evaluate/compare_models.py --data-dir data/scaled
    python evaluate/compare_models.py --data-dir data/scaled --repeats 5

Protocol
  * Repeated stratified K-fold CV (default 5 folds x 3 repeats, fixed seed).
  * Metrics per fold: accuracy, precision, recall, F1, ROC-AUC. Reported as
    mean +- std over folds.
  * NDCG@5 of the per-job candidate ranking, computed on out-of-fold scores
    from the first repeat (how well the model ranks candidates for each job).
  * Decision threshold: 0.5 for the probabilistic classifiers; for the
    un-trained score baselines (keyword overlap, TF-IDF, fixed weights) the
    threshold maximising F1 on the TRAINING fold is used.
  * Wilcoxon signed-rank test (paired over folds) of Logistic-GD vs every
    other row on AUC. Folds from repeated CV overlap, so treat p-values as
    indicative, not exact.

Rows
  Baselines : keyword overlap only | TF-IDF only | fixed hand weights 0.5/0.3/0.2
  Models    : Linear GD (MSE, original) | Logistic GD (ours) | sklearn
              LogisticRegression (sanity check) | GradientBoosting | small MLP
  Ablations : Logistic GD with skill only / skill+CGPA+PUC (default) / + TF-IDF

IMPORTANT: if the labels are rule-derived or simulated (as in the bundled
files) these numbers measure agreement with that rule/simulator, not real
hiring decisions. Replace labels with human or real outcomes for the paper.
"""

import argparse
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, ndcg_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.neural_network import MLPClassifier

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src.weight_optimizer import GDLinearClassifier, GDLogisticClassifier  # noqa: E402

warnings.filterwarnings("ignore")
F_SKILL, F_TEXT, F_CGPA, F_PUC = "skill_match_score", "text_similarity_score", "cgpa_norm", "puc_norm"


class ScoreBaseline:
    """Un-trained score: a fixed linear combination of chosen columns. Only the
    decision threshold is fitted (max F1 on the training fold)."""
    def __init__(self, weights):
        self.w = np.array(weights, dtype=float)

    def fit(self, X, y):
        s = np.asarray(X) @ self.w
        grid = np.unique(np.quantile(s, np.linspace(0.05, 0.95, 91)))
        self.t_ = max(grid, key=lambda t: f1_score(y, s >= t, zero_division=0))
        return self

    def score(self, X):
        return np.asarray(X) @ self.w

    def predict_proba(self, X):
        s = self.score(X)
        p = 1 / (1 + np.exp(-12 * (s - self.t_)))  # monotone; 0.5 at the tuned threshold
        return np.column_stack([1 - p, p])


def build_experiments():
    base3 = [F_SKILL, F_CGPA, F_PUC]
    return [
        ("Baseline: keyword overlap only", [F_SKILL], lambda: ScoreBaseline([1.0])),
        ("Baseline: TF-IDF similarity only", [F_TEXT], lambda: ScoreBaseline([1.0])),
        ("Baseline: fixed weights 0.5/0.3/0.2", base3, lambda: ScoreBaseline([0.5, 0.3, 0.2])),
        ("Linear GD (MSE) - original", base3, lambda: GDLinearClassifier()),
        ("Logistic GD (cross-entropy) - ours", base3, lambda: GDLogisticClassifier()),
        ("sklearn LogisticRegression", base3, lambda: LogisticRegression(C=100, max_iter=2000)),
        ("Gradient Boosting", base3, lambda: GradientBoostingClassifier(random_state=0)),
        ("MLP (16 hidden)", base3, lambda: MLPClassifier((16,), max_iter=800, random_state=0)),
        ("Ablation: Logistic GD, skill only", [F_SKILL], lambda: GDLogisticClassifier()),
        ("Ablation: Logistic GD, + TF-IDF", base3 + [F_TEXT], lambda: GDLogisticClassifier()),
    ]


def fold_metrics(y_true, proba):
    pred = (proba >= 0.5).astype(int)
    auc = roc_auc_score(y_true, proba) if len(set(y_true)) > 1 else np.nan
    return {"accuracy": accuracy_score(y_true, pred),
            "precision": precision_score(y_true, pred, zero_division=0),
            "recall": recall_score(y_true, pred, zero_division=0),
            "f1": f1_score(y_true, pred, zero_division=0), "auc": auc}


def mean_ndcg(df, scores, k=5):
    vals = []
    for _, g in df.assign(_s=scores).groupby("job_id"):
        if g["suitable"].sum() == 0 or len(g) < 2:
            continue
        vals.append(ndcg_score([g["suitable"].values], [g["_s"].values], k=k))
    return float(np.mean(vals)) if vals else np.nan


def run(df, folds, repeats, seed):
    y = df["suitable"].astype(int).values
    results, auc_by_model = [], {}
    rskf = RepeatedStratifiedKFold(n_splits=folds, n_repeats=repeats, random_state=seed)
    oof_split = list(StratifiedKFold(folds, shuffle=True, random_state=seed).split(df, y))

    for name, cols, make in build_experiments():
        X = df[cols].values
        per_fold = []
        for tr, te in rskf.split(X, y):
            m = make().fit(X[tr], y[tr])
            per_fold.append(fold_metrics(y[te], m.predict_proba(X[te])[:, 1]))
        oof = np.zeros(len(df))
        for tr, te in oof_split:
            oof[te] = make().fit(X[tr], y[tr]).predict_proba(X[te])[:, 1]
        pf = pd.DataFrame(per_fold)
        auc_by_model[name] = pf["auc"].values
        row = {"model": name}
        for met in ["accuracy", "precision", "recall", "f1", "auc"]:
            row[met] = f"{pf[met].mean():.3f} +- {pf[met].std():.3f}"
            row[met + "_mean"] = pf[met].mean()
        row["ndcg@5"] = round(mean_ndcg(df, oof), 3)
        results.append(row)
        print(f"  done: {name}")

    ours = auc_by_model["Logistic GD (cross-entropy) - ours"]
    for row in results:
        other = auc_by_model[row["model"]]
        if row["model"].endswith("ours") or np.allclose(ours, other, equal_nan=True):
            row["p_vs_ours(AUC)"] = "-"
        else:
            try:
                row["p_vs_ours(AUC)"] = f"{wilcoxon(ours, other).pvalue:.3g}"
            except ValueError:
                row["p_vs_ours(AUC)"] = "n/a"
    return pd.DataFrame(results)


def to_markdown(res, title, n, pos):
    cols = ["model", "accuracy", "precision", "recall", "f1", "auc", "ndcg@5", "p_vs_ours(AUC)"]
    lines = [f"### {title}", f"{n} labelled pairs, {pos} positive ({100 * pos / n:.1f}%).", "",
             "| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in res.iterrows():
        lines.append("| " + " | ".join(str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=str(ROOT / "data"))
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    d = Path(a.data_dir)
    df = pd.read_csv(d / "labeled_resume_job_pairs.csv")
    df = df[df["suitable"].astype(str).str.strip() != ""].reset_index(drop=True)
    n, pos = len(df), int(df["suitable"].sum())
    print(f"Dataset: {d} | {n} pairs, {pos} positive")
    res = run(df, a.folds, a.repeats, a.seed)

    out = ROOT / "evaluate" / "results"
    out.mkdir(exist_ok=True, parents=True)
    tag = d.name if d.name != "data" else "base"
    res.to_csv(out / f"model_comparison_{tag}.csv", index=False)
    md = to_markdown(res, f"Model comparison - {tag}", n, pos)
    (out / f"model_comparison_{tag}.md").write_text(md + "\n", encoding="utf-8")
    print("\n" + md)


if __name__ == "__main__":
    main()
