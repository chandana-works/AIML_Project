"""
Offline evaluation of the prioritised learning path
===================================================
    python evaluate/evaluate_learning_paths.py                 # data/scaled by default
    python evaluate/evaluate_learning_paths.py --k 3 --n 300

Question: if a candidate learns k of their missing skills for a target job,
does the PRIORITY order beat other orders at opening up the job market?

Metric ("market reach gain"): the number of postings, across ALL jobs, that
the candidate covers at >= 80% of required skills, after minus before.
(The single-job score depends only on HOW MANY skills are learned, so it cannot
tell orders apart - market reach can.)

Arms (each learns k skills from the same missing set):
  priority   first k steps of the learning path (demand/unlock/affinity/quick-win)
  demand     the k most demanded missing skills
  quickest   the k cheapest missing skills (fewest hours)
  random     k random missing skills (mean of 30 draws)

Target job for each resume = best-scoring posting of the resume's own target
role that leaves >= k skills missing. Paired Wilcoxon tests: priority vs each.
Results are written to evaluate/results/learning_path_eval_<data>.md/.csv.
"""

import argparse
import csv
import os
import random
import statistics as st
from pathlib import Path
import sys

from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)

from src import (config, market_insights as mi, pipeline, skill_extraction,
                 skill_gap, skill_priority, weight_optimizer)


def load_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def pick_target(resume, jobs, k, model, taxonomy):
    best = None
    for j in jobs:
        if j["job_role"].strip().lower() != resume["target_role"].strip().lower():
            continue
        scores = pipeline.score_pair(resume, j, model, taxonomy)
        missing = skill_gap.compute_skill_gap(scores["resume_skills"], scores["job_skills"])
        if len(missing) >= k and (best is None or scores["final_score"] > best[0]):
            best = (scores["final_score"], j, scores, missing)
    return best


def evaluate(resumes, jobs, model, taxonomy, stats_, meta, k=3, n=300, seed=0, draws=30):
    rng = random.Random(seed)
    sample = rng.sample(resumes, min(n, len(resumes)))
    rows = []
    for r in sample:
        t = pick_target(r, jobs, k, model, taxonomy)
        if not t:
            continue
        _s, job, scores, missing = t
        have = set(scores["resume_skills"])
        before = mi.jobs_reachable(have, jobs)
        path = skill_priority.build_learning_path(missing, have, stats_, meta)
        arms = {
            "priority": [s["skill"] for s in path["steps"][:k]],
            "demand": sorted(missing, key=lambda s: (-stats_["df"].get(s, 0), s))[:k],
            "quickest": sorted(missing, key=lambda s: (meta.get(s, {}).get("hours", 30), s))[:k],
        }
        row = {"resume_id": r["resume_id"], "job_id": job["job_id"], "n_missing": len(missing), "before": before}
        for name, chosen in arms.items():
            row[name] = mi.jobs_reachable(have | set(chosen), jobs) - before
            row[f"{name}_hours"] = sum(meta.get(s, {}).get("hours", 30) for s in chosen)
        rnd = [mi.jobs_reachable(have | set(rng.sample(missing, k)), jobs) - before for _ in range(draws)]
        row["random"] = sum(rnd) / draws
        rows.append(row)
    return rows


def summarize(rows):
    arms = ["priority", "demand", "quickest", "random"]
    out = {"n": len(rows), "arms": {}}
    for a in arms:
        vals = [r[a] for r in rows]
        hrs = [r[f"{a}_hours"] for r in rows] if a != "random" else None
        out["arms"][a] = {"mean_gain": st.mean(vals), "mean_hours": st.mean(hrs) if hrs else None}
    out["tests"] = {}
    for a in ("random", "demand", "quickest"):
        diffs = [r["priority"] - r[a] for r in rows]
        try:
            p = stats.wilcoxon(diffs).pvalue if any(d != 0 for d in diffs) else 1.0
        except ValueError:
            p = float("nan")
        out["tests"][a] = {"mean_diff": st.mean(diffs), "p": p}
    return out


def to_markdown(summary, k, tag):
    L = [f"# Learning-path evaluation ({tag})", "",
         f"{summary['n']} candidates, k = {k} skills learned, metric = extra postings covered at >= 80%.", "",
         "| Strategy | Mean market-reach gain | Mean hours |", "|---|---|---|"]
    for a, v in summary["arms"].items():
        h = f"{v['mean_hours']:.0f}" if v["mean_hours"] is not None else "-"
        L.append(f"| {a} | {v['mean_gain']:.2f} | {h} |")
    L += ["", "Paired Wilcoxon, priority vs:", ""]
    for a, t in summary["tests"].items():
        L.append(f"* {a}: mean difference {t['mean_diff']:+.2f}, p = {t['p']:.4f}")
    L += ["", "Caveat: measured on the bundled (synthetic) data and on the author's skill-hour and "
              "prerequisite estimates; replicate on the real Naukri/Kaggle data."]
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=None)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    data = Path(args.data_dir) if args.data_dir else config.resolve_data_dir()
    tag = data.name if data.name != "data" else "base"

    X, y = weight_optimizer.load_training_data(str(data / "historical_hiring_data.csv"))
    model = weight_optimizer.fit_model(X, y, kind="logistic")
    taxonomy = skill_extraction.load_skills_taxonomy(str(data / "skills_taxonomy.csv"))
    jobs, resumes = load_csv(data / "job_postings.csv"), load_csv(data / "resumes.csv")
    meta = skill_priority.load_skill_meta(str(data / "skill_meta.csv"))
    stats_ = skill_priority.build_corpus_stats(jobs)

    rows = evaluate(resumes, jobs, model, taxonomy, stats_, meta, k=args.k, n=args.n, seed=args.seed)
    if not rows:
        sys.exit("No candidates with enough missing skills for their target role.")
    summary = summarize(rows)
    md = to_markdown(summary, args.k, tag)
    os.makedirs(os.path.join(ROOT, "evaluate", "results"), exist_ok=True)
    base = os.path.join(ROOT, "evaluate", "results", f"learning_path_eval_{tag}")
    with open(base + ".md", "w", encoding="utf-8") as f:
        f.write(md)
    with open(base + ".csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(md)


if __name__ == "__main__":
    main()
