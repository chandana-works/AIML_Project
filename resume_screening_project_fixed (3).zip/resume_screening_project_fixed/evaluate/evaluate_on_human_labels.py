"""
Evaluate the scorer against HUMAN gold labels
=============================================
    python evaluate/evaluate_on_human_labels.py
    python evaluate/evaluate_on_human_labels.py --sbert        # adds an SBERT arm (needs the package + internet once)

The trained model is NOT retrained on the human labels (too few); it is
evaluated zero-shot against them and compared with simple baselines:
    model          trained logistic model's probability
    keyword        skill-overlap ratio only
    tfidf          TF-IDF cosine similarity only
    fixed_weights  0.5*skill + 0.3*CGPA + 0.2*PUC (hand-set, untrained)
    sbert          (optional) Sentence-BERT cosine of resume text vs job text
Metrics: ROC-AUC and average precision with bootstrap 95% CIs, plus a paired
bootstrap CI for (model - keyword) AUC. Also reports how well the project's
original rule/simulated labels agree with the humans (Cohen's kappa) - this
quantifies how much the synthetic labels can be trusted.
"""

import argparse
import csv
import os
import random
import sys
from pathlib import Path

from sklearn.metrics import average_precision_score, f1_score, roc_auc_score

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)
from src import annotation, config, pipeline, skill_extraction, weight_optimizer


def load_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def _auc(y, s):
    return roc_auc_score(y, s) if 0 < sum(y) < len(y) else float("nan")


def evaluate_arms(y, arms, n_boot=1000, seed=0, baseline_arm="keyword", main_arm="model"):
    """y: list of 0/1; arms: {name: scores}. Returns metrics with bootstrap CIs."""
    rng = random.Random(seed)
    n = len(y)
    out = {"n": n, "positives": sum(y), "arms": {}}
    boots = {a: [] for a in arms}
    for _ in range(n_boot):
        idx = [rng.randrange(n) for _ in range(n)]
        yb = [y[i] for i in idx]
        if not 0 < sum(yb) < n:
            continue
        for a, s in arms.items():
            boots[a].append(roc_auc_score(yb, [s[i] for i in idx]))
        if baseline_arm in arms and main_arm in arms:
            boots.setdefault("_diff", []).append(boots[main_arm][-1] - boots[baseline_arm][-1])
    for a, s in arms.items():
        b = sorted(boots[a])
        out["arms"][a] = {"auc": _auc(y, s), "ap": average_precision_score(y, s),
                          "auc_ci": (b[int(0.025 * len(b))], b[int(0.975 * len(b)) - 1]) if len(b) > 20 else (float("nan"),) * 2}
    d = sorted(boots.get("_diff", []))
    if len(d) > 20:
        out["diff_model_vs_keyword"] = (d[int(0.025 * len(d))], d[int(0.975 * len(d)) - 1])
    return out


def to_markdown(res, kappa_rule=None):
    L = ["# Evaluation against human gold labels", "",
         f"{res['n']} gold pairs ({res['positives']} suitable).", "",
         "| Scorer | ROC-AUC | 95% CI | Avg. precision |", "|---|---|---|---|"]
    for a, m in res["arms"].items():
        L.append(f"| {a} | {m['auc']:.3f} | [{m['auc_ci'][0]:.3f}, {m['auc_ci'][1]:.3f}] | {m['ap']:.3f} |")
    if "diff_model_vs_keyword" in res:
        lo, hi = res["diff_model_vs_keyword"]
        L += ["", f"Paired bootstrap 95% CI of AUC(model) - AUC(keyword): [{lo:+.3f}, {hi:+.3f}] "
                  "(an interval containing 0 means no demonstrated advantage)."]
    if kappa_rule is not None:
        L += ["", f"Agreement of the project's original rule/simulated labels with the humans: "
                  f"Cohen's kappa = {kappa_rule:.3f}."]
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sbert", action="store_true")
    ap.add_argument("--min-pairs", type=int, default=40)
    args = ap.parse_args()

    gold_path = os.path.join(ROOT, "data", "human_labeled_pairs.csv")
    if not os.path.exists(gold_path):
        sys.exit("data/human_labeled_pairs.csv not found - run analyze_annotations.py first.")
    gold = load_csv(gold_path)
    y = [int(g["human_label"]) for g in gold]
    if len(gold) < args.min_pairs or not 0 < sum(y) < len(y):
        sys.exit(f"Need >= {args.min_pairs} gold pairs with both classes present (have {len(gold)}).")

    data = config.resolve_data_dir()
    X, yt = weight_optimizer.load_training_data(str(data / "historical_hiring_data.csv"))
    model = weight_optimizer.fit_model(X, yt, kind="logistic")
    taxonomy = skill_extraction.load_skills_taxonomy(str(data / "skills_taxonomy.csv"))
    jobs = {j["job_id"]: j for j in load_csv(data / "job_postings.csv")}
    resumes = {r["resume_id"]: r for r in load_csv(data / "resumes.csv")}

    arms = {"model": [], "keyword": [], "tfidf": [], "fixed_weights": []}
    texts_a, texts_b = [], []
    for g in gold:
        r, j = resumes[g["resume_id"]], jobs[g["job_id"]]
        s = pipeline.score_pair(r, j, model, taxonomy)
        arms["model"].append(s["final_score"])
        arms["keyword"].append(s["skill_score"])
        arms["tfidf"].append(s["text_similarity_score"])
        arms["fixed_weights"].append(0.5 * s["skill_score"] + 0.3 * s["cgpa_norm"] + 0.2 * s["puc_norm"])
        texts_a.append(pipeline.build_resume_text(r)); texts_b.append(pipeline.build_job_text(j))
    if args.sbert:
        from src import semantic
        arms["sbert"] = semantic.cosine_scores(semantic.load_encoder(), texts_a, texts_b)

    res = evaluate_arms(y, arms)

    kappa_rule = None
    rule_file = data / "labeled_resume_job_pairs.csv"
    if rule_file.exists():
        rule = {f"{r['resume_id']}_{r['job_id']}": r["suitable"] for r in load_csv(rule_file)}
        pairs = [(str(g["human_label"]), rule[g["pair_id"]]) for g in gold if g["pair_id"] in rule]
        if pairs:
            kappa_rule = annotation.cohen_kappa([a for a, _ in pairs], [b for _, b in pairs])

    md = to_markdown(res, kappa_rule)
    outdir = os.path.join(ROOT, "evaluate", "results"); os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, "human_label_eval.md"), "w", encoding="utf-8") as f:
        f.write(md)
    print(md)


if __name__ == "__main__":
    main()
