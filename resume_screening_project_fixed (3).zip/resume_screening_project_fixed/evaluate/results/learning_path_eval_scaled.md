# Learning-path evaluation (scaled)

201 candidates, k = 3 skills learned, metric = extra postings covered at >= 80%.

| Strategy | Mean market-reach gain | Mean hours |
|---|---|---|
| priority | 3.95 | 91 |
| demand | 3.94 | 92 |
| quickest | 3.91 | 89 |
| random | 3.92 | - |

Paired Wilcoxon, priority vs:

* random: mean difference +0.03, p = 0.0741
* demand: mean difference +0.01, p = 0.1573
* quickest: mean difference +0.04, p = 0.1910

Caveat: measured on the bundled (synthetic) data and on the author's skill-hour and prerequisite estimates; replicate on the real Naukri/Kaggle data.
