"""
Build the set of pairs for human annotation
===========================================
    python evaluate/make_annotation_set.py                 # 200 pairs from the active dataset
    python evaluate/make_annotation_set.py --n 300 --seed 1

Samples pairs stratified into 4 equal bins of skill overlap (so annotators see
a spread from clear mismatches to clear matches, not 80% obvious negatives),
shuffles them once, and writes data/annotation_pairs.csv. Both annotators get
the same file in the same order.
Then: SHOW_ANNOTATE_PAGE=1 python app.py  ->  open /annotate
"""

import argparse
import csv
import os
import random
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)
from src import config


def build(rows, n, seed):
    rng = random.Random(seed)
    bins = [[], [], [], []]
    for r in rows:
        s = float(r["skill_match_score"])
        bins[min(int(s * 4), 3)].append(r)
    per = n // 4
    chosen = []
    for b in bins:
        rng.shuffle(b)
        chosen += b[:per]
    rng.shuffle(chosen)
    return [{"pair_id": f"{r['resume_id']}_{r['job_id']}", "resume_id": r["resume_id"],
             "job_id": r["job_id"]} for r in chosen]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    data = config.resolve_data_dir()
    src = data / "labeled_resume_job_pairs.csv"
    if not src.exists():
        sys.exit(f"{src} not found (needed only to stratify by skill overlap).")
    with open(src, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    pairs = build(rows, args.n, args.seed)
    out = os.path.join(ROOT, "data", "annotation_pairs.csv")
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["pair_id", "resume_id", "job_id"])
        w.writeheader(); w.writerows(pairs)
    print(f"Wrote {len(pairs)} pairs to {out}")


if __name__ == "__main__":
    main()
