"""
Analyse the blinded user study  (data/study_responses.csv)
==========================================================
    python evaluate/analyze_study.py
    python evaluate/analyze_study.py --file data/study_responses.csv --out evaluate/results/study_results.md

Reports, for baseline (score only) vs full (score + gaps + learning path):
  * mean usefulness and actionability, and the paired difference (full - baseline)
  * Wilcoxon signed-rank test on PARTICIPANT-level means (one value per person,
    so repeated ratings from one person are not treated as independent)
  * effect size (Cohen's d_z) and a bootstrap 95% CI of the mean difference
  * overall preference share with an exact binomial test (ties excluded)
  * share answering yes / maybe / no to "would this help you improve?"
  * position-bias check: did the full output win more often in slot A or B?

IMPORTANT: with fewer than ~15 participants treat the p-values as indicative.
"""

import argparse
import csv
import os
import random
import statistics as st
import sys
from collections import defaultdict

from scipy import stats

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def participant_means(rows, col):
    by = defaultdict(list)
    for r in rows:
        by[r["participant_id"]].append(float(r[col]))
    return {p: sum(v) / len(v) for p, v in by.items()}


def bootstrap_ci(diffs, n=5000, seed=0):
    rng = random.Random(seed)
    means = sorted(sum(rng.choices(diffs, k=len(diffs))) / len(diffs) for _ in range(n))
    return means[int(0.025 * n)], means[int(0.975 * n)]


def compare(rows, metric):
    b = participant_means(rows, f"baseline_{metric}")
    f = participant_means(rows, f"full_{metric}")
    ids = sorted(b)
    diffs = [f[i] - b[i] for i in ids]
    out = {"metric": metric, "n": len(ids),
           "baseline_mean": st.mean(b[i] for i in ids), "full_mean": st.mean(f[i] for i in ids),
           "mean_diff": st.mean(diffs)}
    sd = st.stdev(diffs) if len(diffs) > 1 else 0.0
    out["dz"] = out["mean_diff"] / sd if sd else float("nan")
    out["ci"] = bootstrap_ci(diffs) if len(diffs) > 1 else (float("nan"),) * 2
    try:
        out["p"] = stats.wilcoxon(diffs).pvalue if any(d != 0 for d in diffs) else 1.0
    except ValueError:
        out["p"] = float("nan")
    return out


def analyse(rows):
    res = {"n_participants": len({r["participant_id"] for r in rows}), "n_ratings": len(rows)}
    res["metrics"] = [compare(rows, m) for m in ("useful", "actionable")]
    prefs = [r["preference"] for r in rows]
    full, base, eq = prefs.count("full"), prefs.count("baseline"), prefs.count("equal")
    res["pref"] = {"full": full, "baseline": base, "equal": eq,
                   "p": stats.binomtest(full, full + base, 0.5).pvalue if full + base else float("nan")}
    helps = [r["would_help"] for r in rows]
    res["help"] = {k: helps.count(k) / len(helps) for k in ("yes", "maybe", "no")}
    pos = {"A": [0, 0], "B": [0, 0]}
    for r in rows:
        if r["preference"] in ("full", "baseline"):
            pos[r["full_position"]][1] += 1
            pos[r["full_position"]][0] += r["preference"] == "full"
    res["position"] = pos
    return res


def to_markdown(res):
    L = [f"# User study results", "",
         f"{res['n_participants']} participants, {res['n_ratings']} pair ratings.", "",
         "| Metric | Baseline | Full | Diff | 95% CI | d_z | Wilcoxon p |", "|---|---|---|---|---|---|---|"]
    for m in res["metrics"]:
        L.append(f"| {m['metric']} | {m['baseline_mean']:.2f} | {m['full_mean']:.2f} | {m['mean_diff']:+.2f} | "
                 f"[{m['ci'][0]:+.2f}, {m['ci'][1]:+.2f}] | {m['dz']:.2f} | {m['p']:.4f} |")
    p = res["pref"]
    L += ["", f"Preference: full {p['full']}, baseline {p['baseline']}, no preference {p['equal']} "
              f"(binomial p = {p['p']:.4f}, ties excluded).",
          "", "Would this help you improve your application? " +
          ", ".join(f"{k} {100 * v:.0f}%" for k, v in res["help"].items()) + ".", "",
          "Position check (full output chosen / decided pairs): " +
          ", ".join(f"slot {k}: {a}/{b}" for k, (a, b) in res["position"].items()) + "."]
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default="data/study_responses.csv")
    ap.add_argument("--out", default="evaluate/results/study_results.md")
    args = ap.parse_args()
    if not os.path.exists(args.file):
        sys.exit(f"{args.file} not found - run the app and collect responses at /study first.")
    rows = load(args.file)
    if not rows:
        sys.exit("No responses yet.")
    md = to_markdown(analyse(rows))
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print(f"Saved to {args.out}")


if __name__ == "__main__":
    main()
