"""
Label Resume-Job Pairs
----------------------

Adds a provisional suitability label to resume_job_pairs.csv.

Label:
    1 = Suitable
    0 = Not Suitable

Initial labeling criteria:
    1. Candidate meets the job's minimum CGPA requirement.
    2. Candidate has at least 50% of the required skills.

These labels are intended for the current prototype.
For the final research paper, the labels should be validated
using human/expert assessment or real hiring outcome data.
"""

import csv


DATA_DIR = "data"


def load_csv(path):
    """Load a CSV file."""
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():

    print("=" * 70)
    print("LABELING RESUME-JOB PAIRS")
    print("=" * 70)

    # ---------------------------------------------------------
    # Load generated resume-job pairs
    # ---------------------------------------------------------

    pairs = load_csv(
        f"{DATA_DIR}/resume_job_pairs.csv"
    )

    # ---------------------------------------------------------
    # Load original job postings
    # ---------------------------------------------------------

    jobs = load_csv(
        f"{DATA_DIR}/job_postings.csv"
    )

    # Create lookup dictionary
    jobs_by_id = {
        job["job_id"]: job
        for job in jobs
    }

    print(f"Loaded {len(pairs)} resume-job pairs.")
    print(f"Loaded {len(jobs)} job postings.")

    # ---------------------------------------------------------
    # Output file
    # ---------------------------------------------------------

    output_path = (
        f"{DATA_DIR}/labeled_resume_job_pairs.csv"
    )

    fieldnames = list(pairs[0].keys()) + [
        "suitable"
    ]

    suitable_count = 0
    unsuitable_count = 0

    # ---------------------------------------------------------
    # Label every pair
    # ---------------------------------------------------------

    with open(
        output_path,
        "w",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames
        )

        writer.writeheader()

        for pair in pairs:

            job = jobs_by_id[pair["job_id"]]

            # Candidate information
            cgpa_norm = float(
                pair["cgpa_norm"]
            )

            # Convert normalized CGPA back approximately
            # to the original CGPA range used by the project.
            candidate_cgpa = cgpa_norm * 10.0

            # Job minimum CGPA
            minimum_cgpa = float(
                job["min_cgpa"]
            )

            # Skill coverage
            skill_match = float(
                pair["skill_match_score"]
            )

            # -------------------------------------------------
            # Suitability rule
            #
            # Candidate must:
            #   1. Meet minimum CGPA
            #   2. Cover at least 50% of required skills
            # -------------------------------------------------

            if (
                candidate_cgpa >= minimum_cgpa
                and skill_match >= 0.50
            ):
                suitable = 1
                suitable_count += 1
            else:
                suitable = 0
                unsuitable_count += 1

            pair["suitable"] = suitable

            writer.writerow(pair)

    # ---------------------------------------------------------
    # Summary
    # ---------------------------------------------------------

    print()
    print("Labeling completed successfully!")
    print()
    print(f"Suitable candidates     : {suitable_count}")
    print(f"Not suitable candidates : {unsuitable_count}")
    print(f"Total pairs             : {len(pairs)}")
    print()
    print("Saved to:")
    print(output_path)
    print("=" * 70)


if __name__ == "__main__":
    main()