
from flask import Flask, render_template, request, session, redirect, url_for, abort
from werkzeug.utils import secure_filename
from pypdf import PdfReader
from pathlib import Path
import csv
import io
import re
import os
import json
import hashlib
import hmac
import threading

from src import (skill_extraction, skill_gap, weight_optimizer, pipeline,
                 explain, skill_priority, simulation, config)

app = Flask(__name__)
app.secret_key = os.environ.get(
    "FLASK_SECRET_KEY", "replace-with-a-long-random-secret"
)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024

_ACRONYMS = {
    "sql", "oop", "css", "html", "aws", "gcp", "api", "ci/cd", "nlp",
    "dsa", "ui", "ux", "k8s", "bi", "etl", "rest api",
}


_DISPLAY = {
    "power bi": "Power BI", "ci/cd": "CI/CD", "node.js": "Node.js", "vue.js": "Vue.js",
    "c++": "C++", "c#": "C#", "scikit-learn": "scikit-learn", "rest api": "REST API",
    "natural language processing": "Natural Language Processing", "spring boot": "Spring Boot",
    "data structures": "Data Structures", "mongodb": "MongoDB", "pytorch": "PyTorch",
    "numpy": "NumPy", "tensorflow": "TensorFlow", "javascript": "JavaScript", "typescript": "TypeScript",
}


def format_skill_label(skill):
    """Display name for a skill: known overrides, acronyms upper-cased
    (e.g. 'sql' -> 'SQL'), otherwise Title Case."""
    skill = skill or ""
    key = skill.lower()
    if key in _DISPLAY:
        return _DISPLAY[key]
    if key in _ACRONYMS:
        return skill.upper()
    return skill.title()


app.jinja_env.filters["skill_label"] = format_skill_label

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = config.resolve_data_dir()          # data/scaled by default; DATASET=base for the small sample
MODEL_TYPE = os.environ.get("MODEL_TYPE", "logistic")   # "logistic" (default) or "linear"
SHOW_MODEL_PAGE = os.environ.get("SHOW_MODEL_PAGE", "0") == "1"   # research/demo page, hidden from end users by default
SHOW_ANNOTATE_PAGE = os.environ.get("SHOW_ANNOTATE_PAGE", "0") == "1"   # gold-label annotation tool, research team only
SAMPLE_DROPDOWN_LIMIT = 60                    # keep the sample-resume dropdown usable on big datasets

# Persistent application records used for the same-job applicant leaderboard.
# Only confirmed uploaded resumes are stored here.
APPLICATIONS_FILE = BASE_DIR / "data" / "applications.json"
_APPLICATIONS_LOCK = threading.Lock()


def load_applications():
    """Load confirmed applicant records from the local JSON store."""
    if not APPLICATIONS_FILE.exists():
        return []
    try:
        with open(APPLICATIONS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def save_applications(applications):
    """Atomically save confirmed applicant records."""
    APPLICATIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    temp_file = APPLICATIONS_FILE.with_suffix(".tmp")
    with open(temp_file, "w", encoding="utf-8") as f:
        json.dump(applications, f, indent=2)
    os.replace(temp_file, APPLICATIONS_FILE)


def applicant_key(resume_row, job_id):
    """Stable key so re-analyzing the same candidate does not duplicate them."""
    email = (resume_row.get("email") or "").strip().lower()
    name = (resume_row.get("candidate_name") or "").strip().lower()
    identity = email if email else name
    return hashlib.sha256(f"{job_id}|{identity}".encode("utf-8")).hexdigest()


def record_application(resume_row, job_row, overall_score):
    """Create/update one applicant record and return the ranked same-job list."""
    job_id = job_row["job_id"]
    key = applicant_key(resume_row, job_id)

    with _APPLICATIONS_LOCK:
        applications = load_applications()
        record = {
            "applicant_key": key,
            "job_id": job_id,
            "job_role": job_row.get("job_role", job_id),
            "company": job_row.get("company", ""),
            "candidate_name": resume_row.get("candidate_name", "Unknown"),
            "score": round(float(overall_score), 1),
        }

        updated = False
        for i, existing in enumerate(applications):
            if existing.get("applicant_key") == key:
                applications[i] = record
                updated = True
                break

        if not updated:
            applications.append(record)

        save_applications(applications)

    same_job = [a for a in applications if a.get("job_id") == job_id]
    same_job.sort(key=lambda item: (-float(item.get("score", 0)), item.get("candidate_name", "").lower()))

    for index, item in enumerate(same_job, start=1):
        item["rank"] = index

    current_rank = next(
        (item["rank"] for item in same_job if item.get("applicant_key") == key),
        None,
    )
    return same_job, current_rank


def load_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


# Load existing project data
print(f"Loading data from {DATA_DIR} ...")
X, y = weight_optimizer.load_training_data(
    str(DATA_DIR / "historical_hiring_data.csv")
)
model = weight_optimizer.fit_model(X, y, kind=MODEL_TYPE)
print(f"Trained {MODEL_TYPE} model on {model.n_train} rows "
      f"(L2={model.l2}); final loss {model.loss_history[-1]:.4f}")

taxonomy = skill_extraction.load_skills_taxonomy(
    str(DATA_DIR / "skills_taxonomy.csv")
)
jobs = load_csv(DATA_DIR / "job_postings.csv")
resumes = load_csv(DATA_DIR / "resumes.csv")
sample_resumes = resumes[:SAMPLE_DROPDOWN_LIMIT]
catalog = skill_gap.load_course_catalog(
    str(DATA_DIR / "course_catalog.csv")
)
skill_meta = skill_priority.load_skill_meta(str(DATA_DIR / "skill_meta.csv"))
corpus_stats = skill_priority.build_corpus_stats(jobs)

jobs_by_id = {j["job_id"]: j for j in jobs}
resumes_by_id = {r["resume_id"]: r for r in resumes}


# ---------------- PDF EXTRACTION ----------------

def extract_pdf_text(file_storage):
    pdf_bytes = file_storage.read()

    reader = PdfReader(io.BytesIO(pdf_bytes))

    if reader.is_encrypted:
        raise ValueError("Password-protected PDFs are not supported.")

    text = "\n".join(page.extract_text() or "" for page in reader.pages)

    if not text.strip():
        raise ValueError(
            "No selectable text was found. This may be a scanned PDF."
        )

    return text


def first_match(patterns, text):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return ""



# Section headers / boilerplate lines that are never a candidate's name,
# even though they often sit at the very top of a resume.
_NON_NAME_LINES = {
    "resume", "curriculum vitae", "cv", "bio data", "bio-data", "biodata",
    "profile", "career objective", "objective", "professional summary",
    "summary", "personal details", "contact", "contact details",
    "contact information", "address", "about me", "portfolio",
}


def looks_like_name(line):
    """
    True if `line` plausibly contains a person's name: 1-5 alphabetic
    words, no digits, no email/url markers, not a known section header.
    """
    line = line.strip()
    if not (3 <= len(line) <= 60):
        return False
    if any(ch.isdigit() for ch in line):
        return False
    if "@" in line or "http" in line.lower() or "www." in line.lower():
        return False
    if line.lower().strip(" :-") in _NON_NAME_LINES:
        return False
    # Allow letters, spaces, and a few common name punctuation marks only.
    if not re.fullmatch(r"[A-Za-z][A-Za-z.'\-]*(?:\s+[A-Za-z][A-Za-z.'\-]*){0,4}", line):
        return False
    return True


def guess_name_from_header(text):
    """
    Most resumes put the candidate's name as the very first line (often in
    large/bold font, with no 'Name:' label at all) - unlike a labelled
    field, this has to be inferred from position and shape rather than a
    fixed pattern. We scan the first several non-empty lines and return
    the first one that looks like a plausible name.
    """
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    for line in lines[:8]:
        if looks_like_name(line):
            return line
    return ""


def extract_candidate_details(text):
    email = first_match(
        [r"\b([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})\b"],
        text,
    )

    # Phone: try labelled fields first (most reliable), then a strict
    # Indian 10-digit mobile pattern, then fall back to a broad generic
    # digit-run pattern (most likely to produce false positives, so tried
    # last).
    phone = first_match(
        [
            r"(?:Phone|Mobile|Mob|Contact|Cell|Tel)\.?\s*(?:No\.?|Number)?\s*[:\-]?\s*(\+?\d[\d\s().-]{7,}\d)",
            r"(?:\+91[-\s]?)(\d{10})(?!\d)",
            r"(?<!\d)([6-9]\d{9})(?!\d)",
            r"(?<!\w)(\+?\d[\d\s().-]{7,}\d)(?!\w)",
        ],
        text,
    )
    phone = re.sub(r"\s+", " ", phone).strip()

    cgpa = first_match(
        [
            r"\bCGPA\b\s*[:\-]?\s*(\d{1,2}(?:\.\d+)?)",
            r"\bC\.G\.P\.A\.?\b\s*[:\-]?\s*(\d{1,2}(?:\.\d+)?)",
        ],
        text,
    )

    puc = first_match(
        [
            r"\bPUC\b[^.\n]{0,35}?(\d{1,3}(?:\.\d+)?)\s*%",
            r"\b(?:12th|class\s*12|HSC)\b[^.\n]{0,35}?(\d{1,3}(?:\.\d+)?)\s*%",
        ],
        text,
    )

    # Name: try an explicit "Name:" label first (unambiguous when present),
    # then fall back to the header heuristic above, since most resumes
    # don't label the name field at all.
    name = first_match(
        [
            r"(?im)^\s*Name\s*[:\-]\s*([A-Za-z][A-Za-z .'-]{1,60})\s*$"
        ],
        text,
    )
    if not name:
        name = guess_name_from_header(text)

    # If still nothing was found, leave it blank for user review.
    skills = skill_extraction.extract_skills(text, taxonomy)
    skills = sorted(set(skills or []))

    return {
        "candidate_name": name,
        "email": email,
        "phone": phone,
        "cgpa": cgpa,
        "puc_percentage": puc,
        "skills": "; ".join(skills),
    }


# ---------------- VALIDATION ----------------

def validate_details(details):
    errors = []

    name = details.get("candidate_name", "").strip()
    email = details.get("email", "").strip()
    phone = details.get("phone", "").strip()
    cgpa = details.get("cgpa", "").strip()
    puc = details.get("puc_percentage", "").strip()

    if not name:
        errors.append("Candidate name is required.")
    elif not re.fullmatch(r"[A-Za-z][A-Za-z .'-]{1,79}", name):
        errors.append("Please enter a valid candidate name.")

    if email and not re.fullmatch(
        r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
        email,
    ):
        errors.append("Please enter a valid email address.")

    if phone:
        digits = re.sub(r"\D", "", phone)
        if not 8 <= len(digits) <= 15:
            errors.append("Please check the phone number.")

    # This implementation assumes a 10-point CGPA scale.
    if cgpa:
        try:
            if not 0 <= float(cgpa) <= 10:
                errors.append("CGPA must be between 0 and 10.")
        except ValueError:
            errors.append("CGPA must be a number.")

    if puc:
        try:
            if not 0 <= float(puc) <= 100:
                errors.append("PUC percentage must be between 0 and 100.")
        except ValueError:
            errors.append("PUC percentage must be a number.")

    return errors


def get_match_label(score):
    if score >= 80:
        return "Excellent Candidate Match"
    elif score >= 65:
        return "Strong Candidate Match"
    elif score >= 50:
        return "Moderate Candidate Match"
    elif score >= 35:
        return "Low Candidate Match"
    return "Poor Candidate Match"


def get_overall_score(scores):
    # Change this list if your pipeline uses a different key.
    possible_keys = [
        "overall_match_score",
        "overall_score",
        "match_score",
        "overall_match",
        "final_score",
    ]

    if isinstance(scores, dict):
        for key in possible_keys:
            if key in scores:
                score = float(scores[key])

                # Convert a 0-1 score to a 0-100 percentage.
                if 0 <= score <= 1:
                    score *= 100

                return max(0.0, min(100.0, score))

    raise KeyError(
        "Overall score not found. Check the dictionary returned by "
        "pipeline.score_pair() in src/pipeline.py."
    )


def build_uploaded_resume(details, job_id):
    job = jobs_by_id[job_id]

    return {
        "resume_id": "UPLOADED",
        "candidate_name": details["candidate_name"],
        "email": details.get("email", ""),
        "phone": details.get("phone", ""),
        "target_role": job.get("job_role", ""),
        "skills": details.get("skills", ""),
        "cgpa": details.get("cgpa", ""),
        "puc_percentage": details.get("puc_percentage", ""),
    }


def build_benchmark_leaderboard(job_row, current_resume_id=None):
    """Rank only the CSV benchmark candidates for this exact job posting."""
    ranked = []
    for resume in resumes:
        try:
            scores = pipeline.score_pair(resume, job_row, model, taxonomy)
            score = get_overall_score(scores)
            ranked.append({
                "resume_id": resume.get("resume_id", ""),
                "candidate_name": resume.get("candidate_name", "Unknown"),
                "score": round(score, 1),
            })
        except (KeyError, ValueError, TypeError):
            # A malformed benchmark row should not break screening for
            # another candidate.
            continue

    ranked.sort(
        key=lambda item: (-float(item.get("score", 0)),
                          item.get("candidate_name", "").lower())
    )

    for index, item in enumerate(ranked, start=1):
        item["rank"] = index

    current_rank = next(
        (item["rank"] for item in ranked
         if item.get("resume_id") == current_resume_id),
        None,
    )
    total = len(ranked)
    # Show the top 10 plus the selected candidate (keeps big datasets readable).
    shown = [item for item in ranked
             if item["rank"] <= 10 or item["rank"] == current_rank]
    return shown, current_rank, total


def render_screening_results(resume_row, job_row, warnings=None, record_applicant=False,
                             show_benchmark=False):
    scores = pipeline.score_pair(
        resume_row, job_row, model, taxonomy
    )
    full = pipeline.generate_full_output(scores, catalog)
    overall_score = get_overall_score(scores)

    applicant_leaderboard = []
    applicant_rank = None
    if record_applicant:
        applicant_leaderboard, applicant_rank = record_application(
            resume_row, job_row, overall_score
        )

    benchmark_leaderboard = []
    benchmark_rank = None
    benchmark_total = 0
    if show_benchmark:
        benchmark_leaderboard, benchmark_rank, benchmark_total = build_benchmark_leaderboard(
            job_row, resume_row.get("resume_id")
        )

    # ---- explainability, learning path, what-if simulation ----
    explanation = explain.explain_score(model, scores["features"])
    learning_path = skill_priority.build_learning_path(
        full["missing_skills"], scores["resume_skills"], corpus_stats,
        skill_meta, full["course_recommendations"],
    )
    ordered = [step["skill"] for step in learning_path["steps"]]
    sim = simulation.simulate_closure(
        model, scores["features"], scores["resume_skills"],
        scores["job_skills"], ordered,
    )
    model_json = {
        "kind": model.kind,
        "weights": model.weights,
        "bias": model.bias,
        "features": scores["features"],
        "matched": sim["matched"],
        "total": sim["total"],
    }

    return render_template(
        "results.html",
        resume=resume_row,
        job=job_row,
        scores=scores,
        full=full,
        overall_score=overall_score,
        match_label=get_match_label(overall_score),
        review_warnings=warnings or [],
        leaderboard=applicant_leaderboard,
        current_rank=applicant_rank,
        benchmark_leaderboard=benchmark_leaderboard,
        benchmark_rank=benchmark_rank,
        benchmark_total=benchmark_total,
        show_benchmark=show_benchmark,
        explanation=explanation,
        learning_path=learning_path,
        sim=sim,
        model_json=model_json,
    )


# ---------------- HOME PAGE ----------------

@app.route("/")
def home():
    return render_template(
        "index.html",
        resumes=sample_resumes,
        jobs=jobs,
    )


# ---------------- EXISTING CSV RESUME FLOW ----------------

@app.route("/analyze", methods=["POST"])
def analyze():
    resume_id = request.form.get("resume_id", "")
    job_id = request.form.get("job_id", "")

    if resume_id not in resumes_by_id or job_id not in jobs_by_id:
        return render_template(
            "index.html",
            resumes=sample_resumes,
            jobs=jobs,
            error="Please select a valid resume and job.",
        ), 400

    return render_screening_results(
        resumes_by_id[resume_id],
        jobs_by_id[job_id],
        show_benchmark=True,
    )


# ---------------- UPLOAD AND EXTRACT ----------------

@app.route("/upload-analyze", methods=["POST"])
def upload_analyze():
    pdf_file = request.files.get("resume_pdf")
    job_id = request.form.get("job_id", "")

    if not pdf_file or not pdf_file.filename:
        return render_template(
            "index.html", resumes=sample_resumes, jobs=jobs,
            error="Please select a PDF resume.",
        ), 400

    if Path(secure_filename(pdf_file.filename)).suffix.lower() != ".pdf":
        return render_template(
            "index.html", resumes=sample_resumes, jobs=jobs,
            error="Only PDF files are supported.",
        ), 400

    if job_id not in jobs_by_id:
        return render_template(
            "index.html", resumes=sample_resumes, jobs=jobs,
            error="Please select a valid job.",
        ), 400

    try:
        text = extract_pdf_text(pdf_file)
        details = extract_candidate_details(text)
    except Exception as exc:
        app.logger.exception("PDF extraction failed")
        return render_template(
            "index.html",
            resumes=sample_resumes,
            jobs=jobs,
            error=f"Could not extract the PDF: {exc}",
        ), 400

    session["pending_details"] = details
    session["pending_job_id"] = job_id

    original_hash = hashlib.sha256(
        json.dumps(details, sort_keys=True).encode("utf-8")
    ).hexdigest()
    session["original_details_hash"] = original_hash

    return render_template(
        "review.html",
        details=details,
        job=jobs_by_id[job_id],
        errors=[],
        warnings=[],
    )


# ---------------- CONFIRM DETAILS AND SCORE ----------------

@app.route("/confirm-resume", methods=["POST"])
def confirm_resume():
    original = session.get("pending_details")
    job_id = session.get("pending_job_id")

    if not original or job_id not in jobs_by_id:
        session.clear()
        return redirect(url_for("home"))

    # Ensure the saved extraction has not changed in the session.
    saved_hash = session.get("original_details_hash", "")
    actual_hash = hashlib.sha256(
        json.dumps(original, sort_keys=True).encode("utf-8")
    ).hexdigest()

    if not hmac.compare_digest(saved_hash, actual_hash):
        session.clear()
        return redirect(url_for("home"))

    details = {
        "candidate_name": request.form.get("candidate_name", "").strip(),
        "email": request.form.get("email", "").strip(),
        "phone": request.form.get("phone", "").strip(),
        "cgpa": request.form.get("cgpa", "").strip(),
        "puc_percentage": request.form.get("puc_percentage", "").strip(),
        "skills": request.form.get("skills", "").strip(),
    }

    errors = validate_details(details)
    warnings = []

    # Flag changed fields for transparency; legitimate corrections are allowed.
    for field, value in details.items():
        if value != original.get(field, ""):
            warnings.append(
                f"{field.replace('_', ' ').title()} was edited. "
                "Please verify it against the original resume."
            )

    if request.form.get("confirm") != "yes":
        errors.append("Please confirm that you reviewed the details.")

    if errors:
        return render_template(
            "review.html",
            details=details,
            job=jobs_by_id[job_id],
            errors=errors,
            warnings=warnings,
        ), 400

    resume_row = build_uploaded_resume(details, job_id)

    try:
        result = render_screening_results(
            resume_row,
            jobs_by_id[job_id],
            warnings=warnings,
            record_applicant=True,
        )
    except Exception:
        app.logger.exception("Scoring pipeline failed")
        return render_template(
            "review.html",
            details=details,
            job=jobs_by_id[job_id],
            errors=[
                "Details were validated, but scoring failed. "
                "Check the score keys and required fields in pipeline.py."
            ],
            warnings=warnings,
        ), 500

    session.clear()
    return result


@app.context_processor
def inject_flags():
    return {"show_model_page": SHOW_MODEL_PAGE}


# ---------------- MODEL & EVALUATION PAGE ----------------

def _loss_polyline(history, width=600, height=170, pad=10, points=120):
    if not history:
        return ""
    step = max(1, len(history) // points)
    pts = history[::step]
    lo, hi = min(pts), max(pts)
    span = (hi - lo) or 1.0
    coords = []
    for i, v in enumerate(pts):
        x = pad + (width - 2 * pad) * i / max(len(pts) - 1, 1)
        yy = pad + (height - 2 * pad) * (1 - (v - lo) / span)
        coords.append(f"{x:.1f},{yy:.1f}")
    return " ".join(coords)


@app.route("/model")
def model_page():
    if not SHOW_MODEL_PAGE:
        abort(404)
    tag = DATA_DIR.name if DATA_DIR.name != "data" else "base"
    results_csv = BASE_DIR / "evaluate" / "results" / f"model_comparison_{tag}.csv"
    comparison = load_csv(results_csv) if results_csv.exists() else []
    card_path = DATA_DIR / "DATA_CARD.md"
    data_card = card_path.read_text(encoding="utf-8") if card_path.exists() else ""
    return render_template(
        "model.html",
        model=model,
        model_type=MODEL_TYPE,
        feature_rows=list(zip(["Skill match", "CGPA (norm.)", "PUC % (norm.)"],
                              model.weights, model.feature_means)),
        loss_points=_loss_polyline(model.loss_history),
        loss_first=model.loss_history[0],
        loss_last=model.loss_history[-1],
        epochs=len(model.loss_history),
        comparison=comparison,
        data_card=data_card,
        dataset_name=tag,
        n_jobs=len(jobs),
        n_resumes=len(resumes),
    )


@app.errorhandler(413)
def file_too_large(_error):
    return render_template(
        "index.html",
        resumes=sample_resumes,
        jobs=jobs,
        error="File too large. Maximum PDF size is 10 MB.",
    ), 413


# ---------------- EXTRA FEATURES (job matches / market insights / user study) ----------------
import features
features.register_features(app, {
    "model": model, "taxonomy": taxonomy, "jobs": jobs, "resumes": resumes,
    "catalog": catalog,
    "skill_meta": skill_meta, "corpus_stats": corpus_stats,
    "study_file": str(BASE_DIR / "data" / "study_responses.csv"),
    "annotate_enabled": SHOW_ANNOTATE_PAGE,
    "annotation_pairs_file": str(BASE_DIR / "data" / "annotation_pairs.csv"),
    "annotations_file": str(BASE_DIR / "data" / "annotations.csv"),
})


if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
