# Submission checklist

Nothing below is done for you; the project only provides the tools. Status: [ ] not done, [x] done.

## Path A - course submission (recommended: keep the project as it is)
Do NOT change the code or retrain/re-run the models; the figures in `evaluate/results/` are what you report.
- [ ] Run the small user study: share `/study` with 15-20 classmates outside your team (see `paper/STUDY_PROTOCOL.md`).
- [ ] Keep a private participant sheet outside the app; the app stays anonymous.
- [ ] `python evaluate/analyze_study.py`, then use the result as it is, even if not significant.
- [ ] Say clearly that the dataset is synthetic with simulated labels (README top note, `data/scaled/DATA_CARD.md`).
- [ ] Report accuracy, precision and recall together (README "Results at a glance": 0.920 / 0.823 / 0.754 for our model), always with the baselines and the synthetic-data caveat.
- [ ] Report the learning-path result as measured: value = prerequisite-correct ordering, not a significant gain over random.
- [ ] Fill the remaining [TODO] items in `paper/PAPER_TEMPLATE.md` (study results, abstract, related work) using only measured numbers.
- [ ] Verify the references in `paper/REFERENCES_TO_VERIFY.md` before citing any.

## Path B - conference submission (optional, much more work)
All of Path A, plus:
- [ ] Real data: `python scripts/build_scaled_dataset.py --mode kaggle --jobs-csv <jobs.csv> --resumes-csv <resumes.csv> --out data/kaggle --label none`, then `DATASET=kaggle python app.py`.
- [ ] Human gold labels: `python evaluate/make_annotation_set.py --n 200`; two annotators use `/annotate` (`SHOW_ANNOTATE_PAGE=1 python app.py`);
      `python evaluate/analyze_annotations.py`; `python evaluate/evaluate_on_human_labels.py` (target kappa >= 0.6).
- [ ] Larger study (20-30 participants), related-work comparison against a published method, optional SBERT (`--sbert`, needs internet once; untested with the real model).
- [ ] Check the venue's template, page limit and any ethics rules for user studies.
