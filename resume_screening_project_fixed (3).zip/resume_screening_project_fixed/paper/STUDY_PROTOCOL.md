# User study protocol

**Question.** Do candidates find the full output (match score + missing skills + prioritised learning path + projected score)
more useful and actionable than a plain match score?

**Design.** Within-subject, blinded. Each participant sees 6 candidate-job examples. For each, two outputs are shown as A and B;
which is the baseline vs the full output is randomised per example and recorded (`full_position`).

**Measures (per example).** Usefulness (1-5) and actionability (1-5) for each output; overall preference (A / B / no preference);
"Would this help you improve your application?" (yes / maybe / no).

**Participants.** A small study: 15-20 classmates or peers from the intended audience (CS/IT students), recruited from OUTSIDE your project team.
Keep a separate private sheet (outside this repo and the app) of who took part, so nobody is counted twice. `paper/participant_log_template.csv` is an anonymous version for the paper (recruitment channel, year of study).

**Procedure.** Share the app's `/study` link. Takes about 5 minutes. Anonymous: random participant ID, no names or emails. Do not change the code or retrain models while the study is running.

**Analysis (pre-specified).** `python evaluate/analyze_study.py`: participant-level means, Wilcoxon signed-rank on the
participant-level paired differences, Cohen's d_z, bootstrap 95% CI, exact binomial test on preference (ties excluded),
position-bias check. Primary outcome: actionability. Decide this BEFORE looking at the data. Report whatever result comes out, even if it is not significant; with 15-20 people the test has low power, so say that and show the confidence interval.

**Ethics.** Check whether your institution requires approval or an informed-consent statement for a survey of this kind.
The intro page states what is stored. Do not collect personal data.

**Known limitations to report.** Participants rate hypothetical candidates, not their own resumes; the full output is longer than
the baseline, so a preference may partly reflect length; small sample (15-20); self-selected classmates.
