# References to verify before citing

These are real works I believe are relevant, listed from memory. **Check every title, author list, venue, year and page
number yourself before citing.** This list is a starting point, not a literature review; you still need to search for
(a) resume-job matching, (b) skill-gap analysis and (c) course/learning-path recommendation papers, especially from 2020 onward.

- Reimers & Gurevych (2019). Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks. EMNLP-IJCNLP.
- Lundberg & Lee (2017). A Unified Approach to Interpreting Model Predictions. NeurIPS. (SHAP; your explanations use exact Shapley values, Shapley 1953.)
- Shapley (1953). A value for n-person games. Contributions to the Theory of Games II.
- Zhu et al. (2018). Person-Job Fit: Adapting the Right Talent for the Right Job with Joint Representation Learning. ACM TMIS.
- Qin et al. (2018). Enhancing Person-Job Fit for Talent Recruitment: An Ability-aware Neural Network Approach. SIGIR.
- Salton & Buckley (1988). Term-weighting approaches in automatic text retrieval. Information Processing & Management. (TF-IDF)
- Cohen (1960). A coefficient of agreement for nominal scales. Educational and Psychological Measurement.
- Landis & Koch (1977). The measurement of observer agreement for categorical data. Biometrics.
- Wilcoxon (1945). Individual comparisons by ranking methods. Biometrics Bulletin.
- Bogen & Rieke (2018). Help Wanted: An Examination of Hiring Algorithms, Equity, and Bias. Upturn. (fairness context)
- European Commission. ESCO: European Skills, Competences, Qualifications and Occupations. (skills taxonomy)

Open gap: you must find and compare against at least one published resume-job matching or skill-gap method.
