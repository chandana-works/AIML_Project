# [Title: e.g. Skill-Gap-Aware Resume Screening with Learning-Path Recommendations for the Indian Tech Job Market]

> Items marked [TODO] need numbers you have not measured yet (user study). Everything else below is filled from `evaluate/results/`.
> Do not write a result you have not measured.

## Abstract
[TODO 150-200 words: problem, method, data, headline results, main limitation. Include the user-study result once collected, whatever it is.]

## 1. Introduction
Score-only resume screeners tell a candidate whether they match but not why or what to improve. [TODO: motivation for India-specific data.]
RQ1: Does a score + missing skills + learning path output help candidates more than a score alone? (user study)
RQ2: How does the learned scorer compare with simple baselines? (model comparison)
RQ3: Does the learning-path prioritisation improve on simple orderings? (learning-path evaluation)
Contributions: [TODO - state only what you actually show].

## 2. Related Work
[TODO from `REFERENCES_TO_VERIFY.md` plus your own search: resume-job matching; explainable hiring models; skill-gap and course recommendation.]

## 3. Method
3.1 Skill extraction (phrase + fuzzy matching against a taxonomy). 3.2 Features: skill overlap, normalised CGPA and PUC %.
3.3 Scorer: logistic regression trained by gradient descent on cross-entropy with L2 chosen by cross-validation (hand-implemented; verified against scikit-learn).
3.4 Explanation: exact Shapley values over 3 features. 3.5 Learning path: topological order over a prerequisite graph with a heuristic priority
(weights 0.4/0.3/0.2/0.1 are assumptions, not learned). 3.6 What-if simulation.

## 4. Data
Synthetic data generated from role templates with a seeded RNG (seed 42): 70 job postings, 400 resumes, 4,800 resume-job pairs, 943 positive (19.6%).
Labels come from a **simulated recruiter** (noisy utility with experience fit and a CGPA cut-off); they are not real hiring outcomes (`data/scaled/DATA_CARD.md`).
A small hand-made file (12 jobs, 12 resumes, 144 pairs) with rule-derived labels is also used for the original comparison.

## 5. Experiments and Results
### 5.1 Model comparison (agreement with simulated labels)
Repeated stratified 5-fold CV x 3, mean +- std (`model_comparison_scaled.md`):

| Model | Accuracy | Precision | Recall | F1 | AUC |
|---|---|---|---|---|---|
| Logistic GD (ours) | 0.920 +- 0.007 | 0.823 +- 0.029 | 0.754 +- 0.029 | 0.787 +- 0.018 | 0.966 +- 0.005 |
| Keyword overlap only | 0.903 +- 0.010 | 0.747 +- 0.033 | 0.767 +- 0.018 | 0.757 +- 0.023 | 0.950 +- 0.008 |
| TF-IDF similarity only | 0.827 +- 0.013 | 0.541 +- 0.023 | 0.801 +- 0.032 | 0.646 +- 0.022 | 0.895 +- 0.012 |
| Fixed weights 0.5/0.3/0.2 | 0.912 +- 0.010 | 0.756 +- 0.034 | 0.818 +- 0.032 | 0.785 +- 0.023 | 0.964 +- 0.006 |
| Linear GD (MSE) | 0.913 +- 0.010 | 0.821 +- 0.039 | 0.713 +- 0.022 | 0.763 +- 0.024 | 0.960 +- 0.006 |
| sklearn LogisticRegression | 0.919 +- 0.006 | 0.819 +- 0.029 | 0.759 +- 0.028 | 0.787 +- 0.016 | 0.965 +- 0.005 |

Our hand-written logistic regression reproduces scikit-learn's. It improves on keyword-only and TF-IDF-only scoring and on the original linear/MSE model
(precision 0.823 vs 0.821 with higher recall 0.754 vs 0.713), but only marginally on hand-set fixed weights (AUC 0.966 vs 0.964; fixed weights have higher recall, 0.818).
These numbers measure agreement with a simulator and must not be read as real-world accuracy.
On the 144-pair rule-labelled file, keyword overlap alone reaches F1 about 0.96, which shows why human or real-outcome labels are needed.

### 5.2 Learning-path ordering (`learning_path_eval_scaled.md`)
201 candidates, k = 3 skills learned, metric = additional postings covered at >= 80% of required skills.
Priority order 3.95, demand-only 3.94, quickest-first 3.91, random 3.92; priority vs random p = 0.074 (Wilcoxon).
The priority order does not demonstrably improve market reach; its contribution is prerequisite-correct ordering and hour estimates.

### 5.3 User study (RQ1)
[TODO after collecting 15-20 responses: run `python evaluate/analyze_study.py` and paste `study_results.md`. Report the result as it comes out, including if it is not significant.]

### 5.4 Optional: human-label evaluation
[Only if you collect annotations: kappa, pairs retained, `human_label_eval.md`.]

## 6. Limitations
* Data are synthetic and labels simulated; metrics measure agreement with the simulator, not hiring outcomes.
* The advantage of the learned scorer over simple baselines is small.
* Priority weights and learning-hour estimates are author-curated assumptions; the priority ordering showed no market-reach gain over random.
* The scorer uses three features and ignores experience, projects and semantic similarity (SBERT not enabled).
* User study: small sample, self-selected classmates, hypothetical candidates, output-length confound.
* Fairness: CGPA/PUC features can encode socio-economic disadvantage; no bias audit has been performed.

## 7. Conclusion and Future Work
[TODO after the study] Real hiring outcomes, human-labelled evaluation, SBERT matching, fairness audit, learned learning-path ranking.

## References
[TODO]
