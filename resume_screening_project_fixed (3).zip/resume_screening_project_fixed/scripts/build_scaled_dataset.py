"""
Build a larger dataset in the same schema as data/*.csv
======================================================

Two modes
---------
1) synthetic   (works offline)  -  python scripts/build_scaled_dataset.py --mode synthetic
   Generates N jobs and M resumes from role templates + a seeded RNG, builds
   resume-job pairs, and labels them with a *simulated recruiter*.

   >>> The labels are SIMULATED. They are for developing/testing the pipeline,
   >>> scaling experiments and sanity checks. They are NOT real hiring
   >>> outcomes - results on this data must not be reported as real-world
   >>> performance. Use real/human labels for the paper (see --label none).

2) kaggle      -  python scripts/build_scaled_dataset.py --mode kaggle \
                      --jobs-csv naukri.csv --resumes-csv resume.csv
   Adapts the real public datasets (Naukri data-science jobs, Kaggle "Resume
   Dataset") into the project schema. Column names are auto-detected
   (case-insensitive) and can be overridden with --job-cols / --resume-cols.
   Skills are extracted with the project's taxonomy (phrase + fuzzy matching).
   CGPA / PUC are parsed from resume text when present; otherwise they are
   IMPUTED (seeded) and flagged in the `academics_source` column.
   --label proxy  : simulated-recruiter labels (pipeline testing only)
   --label none   : leaves `suitable` empty -> export pairs for human annotation

Output (default data/scaled/): job_postings.csv, resumes.csv,
labeled_resume_job_pairs.csv, historical_hiring_data.csv, plus copies of the
taxonomy / course catalog / skill_meta and a DATA_CARD.md.
"""

import argparse
import csv
import random
import re
import shutil
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src import skill_extraction, matching, academic_score, pipeline  # noqa: E402

COMPANIES = ["TCS", "Infosys", "Wipro", "HCL", "Tech Mahindra", "Cognizant", "Accenture",
             "Capgemini", "Flipkart", "Swiggy", "Zomato", "Zoho", "Freshworks", "Razorpay",
             "PhonePe", "Paytm", "Myntra", "HDFC Bank", "ICICI Bank", "LTIMindtree", "Mphasis"]
LOCATIONS = ["Bangalore", "Hyderabad", "Pune", "Chennai", "Mumbai", "Gurugram", "Noida", "Kolkata"]
EXP_BANDS = ["0-2 Years", "1-3 Years", "2-4 Years", "2-5 Years", "3-6 Years"]

ROLES = {
    "Data Analyst": (["sql", "excel", "power bi", "python", "data analysis", "statistics"], ["tableau", "communication", "business intelligence"]),
    "Python Developer": (["python", "django", "rest api", "sql", "git"], ["flask", "docker", "linux"]),
    "Machine Learning Engineer": (["python", "machine learning", "scikit-learn", "pandas", "numpy", "sql"], ["tensorflow", "pytorch", "docker", "aws"]),
    "Software Engineer": (["java", "oop", "data structures", "algorithms", "sql", "git"], ["spring boot", "c++", "agile"]),
    "Backend Developer": (["java", "spring boot", "sql", "rest api", "docker", "git"], ["aws", "mongodb", "kubernetes"]),
    "Data Scientist": (["python", "machine learning", "deep learning", "statistics", "sql", "pandas"], ["tensorflow", "pytorch", "spark", "tableau"]),
    "Frontend Developer": (["javascript", "react", "html", "css", "git"], ["typescript", "angular", "vue.js"]),
    "DevOps Engineer": (["docker", "kubernetes", "aws", "ci/cd", "linux", "git"], ["devops", "azure", "python"]),
    "Full Stack Developer": (["javascript", "react", "node.js", "sql", "rest api", "git"], ["mongodb", "typescript", "docker"]),
    "Cloud Engineer": (["aws", "azure", "docker", "linux", "cloud computing"], ["kubernetes", "gcp", "ci/cd"]),
    "NLP Engineer": (["python", "natural language processing", "machine learning", "deep learning", "pytorch"], ["tensorflow", "pandas"]),
    "Data Engineer": (["python", "sql", "spark", "hadoop", "data warehousing"], ["aws", "linux", "ci/cd"]),
    "BI Developer": (["sql", "power bi", "business intelligence", "data warehousing", "excel"], ["tableau", "data analysis"]),
    ".NET Developer": (["c#", "sql", "rest api", "oop", "git"], ["azure", "angular"]),
}
LEVELS = {"beginner": (0.45, 6.4), "intermediate": (0.72, 7.2), "advanced": (0.92, 8.0)}
JOB_FIELDS = ["job_id", "job_role", "company", "location", "job_experience", "min_cgpa",
              "skills_required", "description"]
RESUME_FIELDS = ["resume_id", "candidate_name", "target_role", "skills", "cgpa",
                 "puc_percentage", "degree_percentage", "experience_years", "academics_source"]


def clip(x, lo, hi):
    return max(lo, min(hi, x))


# ------------------------------------------------------------------ synthetic
def make_jobs(n, rng):
    roles = list(ROLES)
    jobs = []
    for i in range(n):
        role = roles[i % len(roles)]
        core, opt = ROLES[role]
        skills = list(core)
        if len(skills) > 5 and rng.random() < 0.5:
            skills.remove(rng.choice(skills))
        skills += rng.sample(opt, k=rng.randint(0, min(2, len(opt))))
        company, loc = rng.choice(COMPANIES), rng.choice(LOCATIONS)
        jobs.append({
            "job_id": f"J{i + 1:04d}", "job_role": role, "company": company, "location": loc,
            "job_experience": rng.choice(EXP_BANDS),
            "min_cgpa": rng.choice([6.0, 6.5, 7.0, 7.5]),
            "skills_required": ";".join(skills),
            "description": f"{company} is hiring a {role} in {loc}. The role needs hands-on "
                           f"experience with {', '.join(skills[:3])} and related tools.",
        })
    return jobs


def make_resumes(m, rng, all_skills):
    roles = list(ROLES)
    resumes = []
    for i in range(m):
        role = rng.choice(roles)
        level = rng.choices(list(LEVELS), weights=[0.3, 0.45, 0.25])[0]
        p, cg_mu = LEVELS[level]
        core, opt = ROLES[role]
        skills = {s for s in core if rng.random() < p} | {s for s in opt if rng.random() < p * 0.4}
        skills |= set(rng.sample(all_skills, k=rng.randint(0, 2)))
        while len(skills) < 2:
            skills.add(rng.choice(core))
        cgpa = round(clip(rng.gauss(cg_mu, 0.7), 5.0, 9.8), 1)
        puc = round(clip(cgpa * 10 + rng.gauss(0, 6), 50, 99), 1)
        exp = {"beginner": rng.randint(0, 1), "intermediate": rng.randint(1, 3),
               "advanced": rng.randint(2, 5)}[level]
        resumes.append({
            "resume_id": f"R{i + 1:04d}", "candidate_name": f"Candidate_{i + 1:04d}",
            "target_role": role, "skills": ";".join(sorted(skills)), "cgpa": cgpa,
            "puc_percentage": puc, "degree_percentage": round(clip(cgpa * 9.5, 45, 98), 1),
            "experience_years": exp, "academics_source": "synthetic",
        })
    return resumes


# --------------------------------------------------------------------- labels
def _exp_mid(band):
    nums = [float(x) for x in re.findall(r"\d+", band or "")]
    return sum(nums[:2]) / len(nums[:2]) if nums else 0.0


def simulated_recruiter(res, job, skill_cov, rng, threshold=0.70):
    """Label = 1 if a noisy 'recruiter' utility passes a threshold. Uses signals
    the model does NOT see (experience fit, hard CGPA cut-off) plus noise, so a
    fitted model is not simply re-learning its own labelling rule."""
    cgpa, puc = float(res["cgpa"]), float(res["puc_percentage"])
    mid = _exp_mid(job["job_experience"])
    exp_fit = 1.0 if mid <= 0 else min(float(res["experience_years"]) / mid, 1.0)
    cut = 1.0 if cgpa >= float(job["min_cgpa"]) else 0.0
    u = (0.50 * skill_cov + 0.12 * cgpa / 10 + 0.08 * puc / 100
         + 0.15 * exp_fit + 0.15 * cut + rng.gauss(0, 0.07))
    return int(u >= threshold)


# ---------------------------------------------------------------------- pairs
def build_pairs(resumes, jobs, rng, label_mode, per_resume=12):
    by_role = {}
    for j in jobs:
        by_role.setdefault(j["job_role"], []).append(j)
    rows = []
    for r in resumes:
        rs = skill_extraction.parse_semicolon_list(r["skills"])
        same = by_role.get(r["target_role"], [])
        ranked = sorted(jobs, key=lambda j: -len(rs & skill_extraction.parse_semicolon_list(j["skills_required"])))
        chosen = {j["job_id"]: j for j in (same[:4] + ranked[:4])}
        pool = [j for j in jobs if j["job_id"] not in chosen]
        for j in rng.sample(pool, k=min(max(per_resume - len(chosen), 0), len(pool))):
            chosen[j["job_id"]] = j
        for j in chosen.values():
            js = skill_extraction.parse_semicolon_list(j["skills_required"])
            cov = matching.skill_overlap_score(rs, js)
            row = {
                "resume_id": r["resume_id"], "candidate_name": r["candidate_name"],
                "resume_role": r["target_role"], "job_id": j["job_id"], "job_role": j["job_role"],
                "company": j["company"], "skill_match_score": round(cov, 4),
                "text_similarity_score": round(matching.text_similarity_score(
                    pipeline.build_resume_text(r), pipeline.build_job_text(j)), 4),
                "cgpa_norm": round(academic_score.normalize_cgpa(float(r["cgpa"])), 4),
                "puc_norm": round(academic_score.normalize_percentage(float(r["puc_percentage"])), 4),
                "suitable": "",
            }
            if label_mode == "proxy":
                row["suitable"] = simulated_recruiter(r, j, cov, rng)
            rows.append(row)
    return rows


# --------------------------------------------------------------------- kaggle
def _pick(cols, candidates, override=None):
    if override:
        return override
    low = {c.lower().strip(): c for c in cols}
    for cand in candidates:
        if cand in low:
            return low[cand]
    return None


def adapt_jobs(path, taxonomy, rng, max_jobs, overrides):
    import pandas as pd
    df = pd.read_csv(path, encoding="utf-8", on_bad_lines="skip")
    c = {k: _pick(df.columns, v, overrides.get(k)) for k, v in {
        "title": ["job title", "job_title", "title", "role"],
        "skills": ["key skills", "skills", "key_skills", "skills_required"],
        "exp": ["job experience required", "experience", "job_experience"],
        "loc": ["location", "job location"],
        "company": ["company", "company name", "employer"],
        "desc": ["job description", "description"],
    }.items()}
    if not c["title"] or not c["skills"]:
        raise SystemExit(f"Could not detect title/skills columns in {path}: {list(df.columns)}. "
                         "Pass --job-cols title=<col>,skills=<col>")
    jobs, seen = [], set()
    for _, row in df.iterrows():
        text = str(row[c["skills"]]).replace("|", " ; ").replace(",", " ; ")
        skills = sorted(skill_extraction.extract_skills(text, taxonomy))
        title = str(row[c["title"]]).strip()
        key = (title.lower(), tuple(skills))
        if len(skills) < 3 or key in seen:
            continue
        seen.add(key)
        loc = str(row[c["loc"]]).split(",")[0].strip() if c["loc"] else "India"
        jobs.append({
            "job_id": f"J{len(jobs) + 1:04d}", "job_role": title,
            "company": str(row[c["company"]]).strip() if c["company"] else "Not specified",
            "location": loc, "job_experience": str(row[c["exp"]]).strip() if c["exp"] else "",
            "min_cgpa": 6.5, "skills_required": ";".join(skills),
            "description": str(row[c["desc"]])[:400] if c["desc"] and str(row[c["desc"]]) != "nan"
                           else f"{title}. Skills: {', '.join(skills)}.",
        })
    rng.shuffle(jobs)
    jobs = jobs[:max_jobs]
    for i, j in enumerate(jobs, 1):
        j["job_id"] = f"J{i:04d}"
    return jobs


def adapt_resumes(path, taxonomy, rng, max_resumes, overrides):
    import pandas as pd
    df = pd.read_csv(path, encoding="utf-8", on_bad_lines="skip")
    text_col = _pick(df.columns, ["resume", "resume_str", "resume_text", "text"], overrides.get("text"))
    cat_col = _pick(df.columns, ["category", "role", "job_category"], overrides.get("category"))
    if not text_col:
        raise SystemExit(f"Could not detect the resume text column: {list(df.columns)}. "
                         "Pass --resume-cols text=<col>,category=<col>")
    df = df.sample(frac=1.0, random_state=rng.randint(0, 10**6)).head(max_resumes)
    resumes = []
    for _, row in df.iterrows():
        text = str(row[text_col])
        skills = sorted(skill_extraction.extract_skills(text, taxonomy))
        if len(skills) < 2:
            continue
        m_c = re.search(r"\bCGPA\b\s*[:\-]?\s*(\d{1,2}(?:\.\d+)?)", text, re.I)
        m_p = re.search(r"\b(?:PUC|12th|HSC)\b[^.\n]{0,35}?(\d{1,3}(?:\.\d+)?)\s*%", text, re.I)
        parsed = bool(m_c and m_p and 0 < float(m_c.group(1)) <= 10 and 0 < float(m_p.group(1)) <= 100)
        cgpa = float(m_c.group(1)) if parsed else round(clip(rng.gauss(7.2, 0.8), 5.0, 9.8), 1)
        puc = float(m_p.group(1)) if parsed else round(clip(cgpa * 10 + rng.gauss(0, 6), 50, 99), 1)
        resumes.append({
            "resume_id": f"R{len(resumes) + 1:04d}", "candidate_name": f"Candidate_{len(resumes) + 1:04d}",
            "target_role": str(row[cat_col]) if cat_col else "Unknown", "skills": ";".join(skills),
            "cgpa": cgpa, "puc_percentage": puc, "degree_percentage": round(cgpa * 9.5, 1),
            "experience_years": rng.randint(0, 4),
            "academics_source": "parsed" if parsed else "imputed",
        })
    return resumes


# ------------------------------------------------------------------------ io
def write_csv(path, fields, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def parse_kv(s):
    return dict(p.split("=", 1) for p in s.split(",") if "=" in p) if s else {}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mode", choices=["synthetic", "kaggle"], default="synthetic")
    ap.add_argument("--out", default=str(ROOT / "data" / "scaled"))
    ap.add_argument("--n-jobs", type=int, default=70)
    ap.add_argument("--n-resumes", type=int, default=400)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--label", choices=["proxy", "none"], default="proxy")
    ap.add_argument("--jobs-csv")
    ap.add_argument("--resumes-csv")
    ap.add_argument("--job-cols", default="", help="e.g. title=Job Title,skills=Key Skills")
    ap.add_argument("--resume-cols", default="", help="e.g. text=Resume,category=Category")
    a = ap.parse_args()

    rng = random.Random(a.seed)
    data = ROOT / "data"
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    taxonomy = skill_extraction.load_skills_taxonomy(str(data / "skills_taxonomy.csv"))
    all_skills = sorted(set(taxonomy.values()))

    if a.mode == "synthetic":
        jobs = make_jobs(a.n_jobs, rng)
        resumes = make_resumes(a.n_resumes, rng, all_skills)
        provenance = "SYNTHETIC jobs/resumes (role templates + seeded RNG)."
    else:
        if not (a.jobs_csv and a.resumes_csv):
            raise SystemExit("--mode kaggle needs --jobs-csv and --resumes-csv")
        jobs = adapt_jobs(a.jobs_csv, taxonomy, rng, a.n_jobs, parse_kv(a.job_cols))
        resumes = adapt_resumes(a.resumes_csv, taxonomy, rng, a.n_resumes, parse_kv(a.resume_cols))
        provenance = f"Adapted from {Path(a.jobs_csv).name} and {Path(a.resumes_csv).name}."

    pairs = build_pairs(resumes, jobs, rng, a.label)
    write_csv(out / "job_postings.csv", JOB_FIELDS, jobs)
    write_csv(out / "resumes.csv", RESUME_FIELDS, resumes)
    pair_fields = ["resume_id", "candidate_name", "resume_role", "job_id", "job_role", "company",
                   "skill_match_score", "text_similarity_score", "cgpa_norm", "puc_norm", "suitable"]
    write_csv(out / "labeled_resume_job_pairs.csv", pair_fields, pairs)

    labeled = [p for p in pairs if p["suitable"] != ""]
    if labeled:
        hist = [{"skill_match_score": p["skill_match_score"], "cgpa_norm": p["cgpa_norm"],
                 "puc_norm": p["puc_norm"], "shortlisted": p["suitable"]} for p in labeled]
        write_csv(out / "historical_hiring_data.csv",
                  ["skill_match_score", "cgpa_norm", "puc_norm", "shortlisted"], hist)
    else:
        # keep the app runnable: reuse the small hand-made file until labels exist
        shutil.copy(data / "historical_hiring_data.csv", out / "historical_hiring_data.csv")
    for name in ("skills_taxonomy.csv", "course_catalog.csv", "skill_meta.csv"):
        shutil.copy(data / name, out / name)

    pos = sum(int(p["suitable"]) for p in labeled)
    card = f"""# Data card - {out.name}

- Provenance: {provenance}
- Jobs: {len(jobs)} | Resumes: {len(resumes)} | Resume-job pairs: {len(pairs)}
- Labels: {'SIMULATED recruiter (proxy) - NOT real hiring outcomes' if a.label == 'proxy' else 'NONE - annotate `suitable` by hand'}
- Positive rate: {pos}/{len(labeled)} ({100 * pos / max(len(labeled), 1):.1f}%)
- Seed: {a.seed}
- Top roles: {dict(Counter(j['job_role'] for j in jobs).most_common(5))}

Do not report accuracy on proxy-labelled data as real-world performance.
"""
    (out / "DATA_CARD.md").write_text(card, encoding="utf-8")
    print(card)


if __name__ == "__main__":
    main()
