"""
Generate Resume-Job Pair Dataset
---------------------------------
Creates every possible combination of the available resumes and jobs.

For each resume-job pair, we calculate:
    1. Skill overlap score
    2. Text similarity score
    3. Normalized CGPA
    4. Normalized PUC percentage

The generated dataset will be saved as:

    data/resume_job_pairs.csv

This file will later be used to create the research/training dataset.
"""

import csv

from src import matching
from src import academic_score


DATA_DIR = "data"


def load_csv(path):
    """Load a CSV file and return a list of dictionaries."""
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def build_resume_text(resume):
    """
    Build text representing the candidate's resume.

    We use the target role and listed skills as the textual
    representation for TF-IDF similarity.
    """
    return (
        f"{resume['target_role']} "
        f"{resume['skills'].replace(';', ' ')}"
    )


def build_job_text(job):
    """
    Build text representing the job posting.

    We include the job role, required skills, and description.
    """
    return (
        f"{job['job_role']} "
        f"{job['skills_required'].replace(';', ' ')} "
        f"{job['description']}"
    )


def calculate_pair_features(resume, job):
    """Calculate all features for one resume-job pair."""

    # Convert skill strings into sets
    resume_skills = {
        skill.strip().lower()
        for skill in resume["skills"].split(";")
        if skill.strip()
    }

    job_skills = {
        skill.strip().lower()
        for skill in job["skills_required"].split(";")
        if skill.strip()
    }

    # 1. Skill overlap
    skill_score = matching.skill_overlap_score(
        resume_skills,
        job_skills
    )

    # 2. TF-IDF + cosine similarity
    resume_text = build_resume_text(resume)
    job_text = build_job_text(job)

    text_score = matching.text_similarity_score(
        resume_text,
        job_text
    )

    # 3. Normalize CGPA
    cgpa_norm = academic_score.normalize_cgpa(
        float(resume["cgpa"])
    )

    # 4. Normalize PUC percentage
    puc_norm = academic_score.normalize_percentage(
        float(resume["puc_percentage"])
    )

    return (
        skill_score,
        text_score,
        cgpa_norm,
        puc_norm
    )


def main():

    print("=" * 70)
    print("GENERATING RESUME-JOB PAIR DATASET")
    print("=" * 70)

    # Load resumes
    resumes = load_csv(
        f"{DATA_DIR}/resumes.csv"
    )

    # Load jobs
    jobs = load_csv(
        f"{DATA_DIR}/job_postings.csv"
    )

    print(f"Loaded {len(resumes)} resumes.")
    print(f"Loaded {len(jobs)} jobs.")

    # Output file
    output_path = (
        f"{DATA_DIR}/resume_job_pairs.csv"
    )

    fieldnames = [
        "resume_id",
        "candidate_name",
        "resume_role",
        "job_id",
        "job_role",
        "company",
        "skill_match_score",
        "text_similarity_score",
        "cgpa_norm",
        "puc_norm"
    ]

    pair_count = 0

    with open(
        output_path,
        "w",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames
        )

        writer.writeheader()

        # Generate every possible resume-job combination
        for resume in resumes:

            for job in jobs:

                (
                    skill_score,
                    text_score,
                    cgpa_norm,
                    puc_norm
                ) = calculate_pair_features(
                    resume,
                    job
                )

                writer.writerow({
                    "resume_id": resume["resume_id"],
                    "candidate_name": resume["candidate_name"],
                    "resume_role": resume["target_role"],
                    "job_id": job["job_id"],
                    "job_role": job["job_role"],
                    "company": job["company"],
                    "skill_match_score": round(
                        skill_score, 4
                    ),
                    "text_similarity_score": round(
                        text_score, 4
                    ),
                    "cgpa_norm": round(
                        cgpa_norm, 4
                    ),
                    "puc_norm": round(
                        puc_norm, 4
                    )
                })

                pair_count += 1

    print()
    print("Dataset generated successfully!")
    print(f"Total resume-job pairs: {pair_count}")
    print()
    print(f"Saved to:")
    print(output_path)
    print("=" * 70)


if __name__ == "__main__":
    main()