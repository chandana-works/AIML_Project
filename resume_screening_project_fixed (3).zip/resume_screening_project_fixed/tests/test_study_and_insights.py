import csv, os, random, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import market_insights as mi, study

JOBS = [{"job_id": "J1", "job_role": "A", "location": "Pune", "skills_required": "python;sql"},
        {"job_id": "J2", "job_role": "A", "location": "Pune", "skills_required": "python;java"},
        {"job_id": "J3", "job_role": "B", "location": "Delhi", "skills_required": "go"}]
RES = [{"resume_id": "R1", "skills": "python;sql"}, {"resume_id": "R2", "skills": "python"}]


class TestInsights(unittest.TestCase):
    def test_demand_supply_gap(self):
        d = {x["skill"]: x["percent"] for x in mi.demand_by_skill(JOBS)}
        self.assertEqual(d["python"], 66.7)
        gap = {g["skill"]: g["gap"] for g in mi.skill_gap_index(JOBS, RES, top_n=10)}
        self.assertEqual(gap["go"], 33.3)          # demanded, nobody has it
        self.assertEqual(gap["python"], -33.3)     # more supply than demand

    def test_reachable_and_counts(self):
        self.assertEqual(mi.jobs_reachable({"python", "sql"}, JOBS, 0.8), 1)
        self.assertEqual(mi.jobs_reachable({"python"}, JOBS, 0.5), 2)
        self.assertEqual(mi.count_by(JOBS, "location")[0], {"label": "Pune", "count": 2})


class TestStudyLogic(unittest.TestCase):
    PAIR = {"resume_id": "R1", "job_id": "J1", "full_position": "B"}

    def form(self, **kw):
        base = {"useful_A": "2", "actionable_A": "1", "useful_B": "5", "actionable_B": "4",
                "preference": "B", "would_help": "yes"}
        base.update(kw); return base

    def test_unscramble(self):
        p = study.parse_response(self.form(), self.PAIR)
        self.assertEqual((p["baseline_useful"], p["full_useful"]), (2, 5))
        self.assertEqual(p["preference"], "full")
        self.assertEqual(study.parse_response(self.form(preference="A"), self.PAIR)["preference"], "baseline")
        self.assertEqual(study.parse_response(self.form(preference="equal"), self.PAIR)["preference"], "equal")

    def test_validation(self):
        for bad in (self.form(useful_A="9"), self.form(useful_A="x"), self.form(preference="C"),
                    self.form(would_help="idk")):
            with self.assertRaises(ValueError):
                study.parse_response(bad, self.PAIR)

    def test_append_and_analyse(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "r.csv")
            for i in range(8):
                pid = f"P{i}"
                for n in (1, 2):
                    parsed = study.parse_response(self.form(useful_B=str(4 + (i + n) % 2), preference="B"), self.PAIR)
                    study.append_response(path, pid, n, self.PAIR, parsed)
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "evaluate"))
            import analyze_study
            res = analyze_study.analyse(analyze_study.load(path))
            self.assertEqual(res["n_participants"], 8)
            self.assertGreater(res["metrics"][0]["mean_diff"], 0)
            self.assertEqual(res["pref"]["full"], 16)
            self.assertIn("User study results", analyze_study.to_markdown(res))


class TestStudyRoutes(unittest.TestCase):
    def test_full_flow(self):
        import app as app_module
        with tempfile.TemporaryDirectory() as d:
            # re-register is not possible, so point the existing store at a temp file via ctx closure
            import features
            from flask import Flask
            a = Flask(__name__, template_folder=str(app_module.BASE_DIR / "templates"))
            a.secret_key = "t"
            a.jinja_env.filters["skill_label"] = app_module.format_skill_label
            a.add_url_rule("/", "home", lambda: "")
            a.add_url_rule("/model", "model_page", lambda: "")
            a.context_processor(lambda: {"show_model_page": False})
            store = os.path.join(d, "resp.csv")
            features.register_features(a, {
                "model": app_module.model, "taxonomy": app_module.taxonomy, "jobs": app_module.jobs,
                "resumes": app_module.resumes, "catalog": app_module.catalog,
                "skill_meta": app_module.skill_meta,
                "corpus_stats": app_module.corpus_stats, "study_file": store})
            c = a.test_client()
            self.assertEqual(c.get("/study").status_code, 200)
            self.assertEqual(c.get("/insights").status_code, 200)
            self.assertEqual(c.get("/study/1").status_code, 302)       # no session -> intro
            r = c.post("/study/start"); self.assertEqual(r.status_code, 302)
            for n in range(1, 7):
                page = c.get(f"/study/{n}"); self.assertEqual(page.status_code, 200)
                self.assertIn(b"Output A", page.data)
                bad = c.post(f"/study/{n}", data={"useful_A": "3"}); self.assertEqual(bad.status_code, 400)
                ok = c.post(f"/study/{n}", data={"useful_A": "3", "actionable_A": "3", "useful_B": "4",
                                                 "actionable_B": "4", "preference": "A", "would_help": "maybe"})
                self.assertEqual(ok.status_code, 302)
            self.assertEqual(c.get("/study/done").status_code, 200)
            with open(store, newline="") as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(len(rows), 6)
            self.assertEqual(len({r["participant_id"] for r in rows}), 1)


if __name__ == "__main__":
    unittest.main()
