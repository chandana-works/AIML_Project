"""Run:  python -m unittest discover -s tests -v"""
import csv
import itertools
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from src import (weight_optimizer as wo, explain, skill_priority as sp,
                 simulation, pipeline, skill_extraction)

DATA = ROOT / "data"


def rows(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


class TestModels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.X, cls.y = wo.load_training_data(str(DATA / "historical_hiring_data.csv"))

    def test_logistic_loss_decreases(self):
        m = wo.fit_model(self.X, self.y, "logistic")
        self.assertLess(m.loss_history[-1], m.loss_history[0])
        self.assertTrue(all(0 <= m.predict(x) <= 1 for x in self.X))

    def test_gradient_matches_finite_difference(self):
        X, y = np.array(self.X), np.array(self.y)
        w, b = np.array([0.3, -0.2, 0.5]), 0.1
        def loss(w, b):
            return wo.cross_entropy(y, wo.sigmoid(X @ w + b))
        p = wo.sigmoid(X @ w + b)
        analytic = X.T @ (p - y) / len(y)
        for i in range(3):
            e = np.zeros(3); e[i] = 1e-6
            numeric = (loss(w + e, b) - loss(w - e, b)) / 2e-6
            self.assertAlmostEqual(analytic[i], numeric, places=6)

    def test_numpy_linear_equals_pure_python(self):
        w1, b1, _ = wo.train(self.X, self.y, learning_rate=0.05, epochs=500)
        w2, b2 = wo.train_linear_np(self.X, self.y, 0.05, 500)
        for a, b in zip(w1, w2):
            self.assertAlmostEqual(a, b, places=9)
        self.assertAlmostEqual(b1, b2, places=9)

    def test_matches_sklearn_with_equivalent_penalty(self):
        """Our hand-written GD (internal z-scoring + mapping back to raw
        features) must agree with scikit-learn's solver for the same objective."""
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
        rws = rows(DATA / "labeled_resume_job_pairs.csv")
        X = np.array([[float(r["skill_match_score"]), float(r["cgpa_norm"]), float(r["puc_norm"])] for r in rws])
        y = np.array([int(r["suitable"]) for r in rws])
        lam = 0.05
        w, b, _ = wo.train_logistic(X, y, l2=lam, epochs=6000)
        ours = wo.sigmoid(X @ np.array(w) + b)
        Z = StandardScaler().fit_transform(X)
        sk = LogisticRegression(C=1.0 / (len(y) * lam), max_iter=5000).fit(Z, y).predict_proba(Z)[:, 1]
        self.assertLess(np.max(np.abs(ours - sk)), 0.01)


class TestExplain(unittest.TestCase):
    def test_shapley_additivity_and_sign(self):
        X, y = wo.load_training_data(str(DATA / "historical_hiring_data.csv"))
        for kind in ("logistic", "linear"):
            m = wo.fit_model(X, y, kind)
            for feats in ([0.9, 0.8, 0.85], [0.1, 0.5, 0.5], [0.5, 0.2, 0.9]):
                ex = explain.explain_score(m, feats)
                total = ex["baseline"] + sum(i["contribution"] for i in ex["items"])
                self.assertAlmostEqual(total, ex["final"], places=6)
        m = wo.fit_model(X, y, "logistic")
        hi = explain.explain_score(m, [0.95, 0.9, 0.9])
        self.assertGreater(hi["final"], hi["baseline"])
        self.assertTrue(all(i["contribution"] > 0 for i in hi["items"]))


class TestPriority(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.meta = sp.load_skill_meta(str(DATA / "skill_meta.csv"))
        cls.stats = sp.build_corpus_stats(rows(DATA / "job_postings.csv"))

    def test_prerequisites_come_first(self):
        missing = ["power bi", "sql", "excel", "statistics", "data analysis", "python"]
        path = sp.build_learning_path(missing, {"communication"}, self.stats, self.meta)
        order = [s["skill"] for s in path["steps"]]
        self.assertEqual(sorted(order), sorted(missing))
        self.assertLess(order.index("sql"), order.index("power bi"))
        self.assertLess(order.index("excel"), order.index("power bi"))
        self.assertLess(order.index("statistics"), order.index("data analysis"))

    def test_hours_and_empty(self):
        path = sp.build_learning_path(["sql", "git"], set(), self.stats, self.meta)
        self.assertEqual(path["total_hours"], 25 + 10)
        self.assertEqual(path["steps"][-1]["cum_hours"], path["total_hours"])
        self.assertEqual(sp.build_learning_path([], set(), self.stats, self.meta)["steps"], [])

    def test_graph_is_acyclic_and_complete(self):
        cache = {}
        for s in self.meta:
            sp._ancestors(s, self.meta, cache)
        self.assertFalse([s for s in self.meta if s in cache[s]])
        tax = set(skill_extraction.load_skills_taxonomy(str(DATA / "skills_taxonomy.csv")).values())
        self.assertFalse(tax - set(self.meta))


class TestCourseLinks(unittest.TestCase):
    def test_every_missing_skill_gets_a_working_link(self):
        from src import skill_gap
        cat = skill_gap.load_course_catalog(str(DATA / "course_catalog.csv"))
        skills = list(skill_extraction.load_skills_taxonomy(str(DATA / "skills_taxonomy.csv")).values())
        recs = skill_gap.recommend_courses(sorted(set(skills)) + ["totally new skill"], cat)
        for skill, rec in recs.items():
            self.assertTrue(rec["course_url"].startswith("https://"), skill)
            self.assertEqual(len(rec["links"]), 2, skill)
        self.assertIn("totally+new+skill", recs["totally new skill"]["course_url"])
        self.assertFalse(recs["spark"]["auto"])
        self.assertFalse(recs["tensorflow"]["auto"])


class TestSimulation(unittest.TestCase):
    def test_monotone_and_consistent_with_pipeline(self):
        X, y = wo.load_training_data(str(DATA / "historical_hiring_data.csv"))
        m = wo.fit_model(X, y, "logistic")
        jobs, res = rows(DATA / "job_postings.csv"), rows(DATA / "resumes.csv")
        tax = skill_extraction.load_skills_taxonomy(str(DATA / "skills_taxonomy.csv"))
        sc = pipeline.score_pair(res[9], jobs[0], m, tax)
        missing = sorted(sc["job_skills"] - sc["resume_skills"])
        sim = simulation.simulate_closure(m, sc["features"], sc["resume_skills"], sc["job_skills"], missing)
        scores = [sim["base"]] + [s["score"] for s in sim["steps"]]
        self.assertEqual(scores, sorted(scores))
        self.assertAlmostEqual(sim["base"], 100 * sc["final_score"], places=9)
        # learning every missing skill == full skill coverage when re-scored directly
        f = list(sc["features"]); f[0] = 1.0
        self.assertAlmostEqual(sim["ceiling"], 100 * m.predict(f), places=9)


class TestPipelineMissingAcademics(unittest.TestCase):
    def test_blank_cgpa_puc_are_imputed_not_crashing(self):
        X, y = wo.load_training_data(str(DATA / "historical_hiring_data.csv"))
        m = wo.fit_model(X, y, "logistic")
        jobs = rows(DATA / "job_postings.csv")
        r = {"skills": "python;sql", "target_role": "x", "cgpa": "", "puc_percentage": ""}
        sc = pipeline.score_pair(r, jobs[0], m, {})
        self.assertEqual(sc["imputed"], ["CGPA", "PUC %"])
        self.assertAlmostEqual(sc["cgpa_norm"], m.feature_means[1])


if __name__ == "__main__":
    unittest.main()
