import os, sys, types, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import job_recommender

def fake_score(resume, job):
    have = set(resume["skills"].split(";"))
    need = set(job["skills_required"].split(";"))
    pct = 100 * len(have & need) / len(need)
    return pct, {"resume_skills": have, "job_skills": need}, {}


JOBS = [{"job_id": "J1", "job_role": "A", "company": "X", "skills_required": "python;sql"},
        {"job_id": "J2", "job_role": "B", "company": "Y", "skills_required": "java;go"}]
RES = [{"resume_id": "R1", "candidate_name": "=evil", "skills": "python;sql"},
       {"resume_id": "R2", "candidate_name": "Bo", "skills": "python"}]


class TestRecommender(unittest.TestCase):
    def test_recommend_order(self):
        r = job_recommender.recommend_jobs(RES[1], JOBS, fake_score)
        self.assertEqual([x["job_id"] for x in r], ["J1", "J2"])
        self.assertEqual(r[0]["missing"], ["sql"])

    def test_demand(self):
        d = job_recommender.skill_demand_summary(JOBS, ["python"], top_n=2)
        self.assertEqual(d[0]["jobs"], 1)


class TestRoutes(unittest.TestCase):
    """Integration tests against the real app, model and dataset."""

    @classmethod
    def setUpClass(cls):
        import app as app_module
        cls.c = app_module.app.test_client()
        cls.resume_id = app_module.resumes[0]["resume_id"]

    def test_pages_load(self):
        for url in ("/recommend", "/insights", "/study", "/"):
            self.assertEqual(self.c.get(url).status_code, 200, url)

    def test_removed_pages_are_gone(self):
        for url in ("/resume-check", "/recruiter"):
            self.assertEqual(self.c.get(url).status_code, 404, url)

    def test_recommend_sample_and_manual(self):
        r = self.c.post("/recommend", data={"resume_id": self.resume_id})
        self.assertEqual(r.status_code, 200); self.assertIn(b"Top matches", r.data)
        r = self.c.post("/recommend", data={"skills": "python, sql", "cgpa": "8", "puc_percentage": "80"})
        self.assertEqual(r.status_code, 200); self.assertIn(b"Top matches", r.data)
        self.assertEqual(self.c.post("/recommend", data={}).status_code, 400)


if __name__ == "__main__":
    unittest.main()
