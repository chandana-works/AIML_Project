import csv, os, random, sys, tempfile, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "evaluate"))

from src import annotation, semantic


def ann(annotator, pid, label):
    return {"annotator": annotator, "pair_id": pid, "resume_id": "R" + pid, "job_id": "J" + pid, "label": label}


class TestAnnotationLogic(unittest.TestCase):
    def test_kappa_values(self):
        self.assertAlmostEqual(annotation.cohen_kappa(list("1100"), list("1100")), 1.0)
        self.assertAlmostEqual(annotation.cohen_kappa(list("1100"), list("0011")), -1.0)
        # textbook example: po = 0.7, pe = 0.5 -> kappa = 0.4
        a = list("1" * 5 + "0" * 5); b = list("1" * 4 + "0" + "1" * 2 + "0" * 3)
        self.assertAlmostEqual(annotation.cohen_kappa(a, b), 0.4, places=6)

    def test_bands(self):
        self.assertEqual(annotation.kappa_band(0.7), "substantial")
        self.assertEqual(annotation.kappa_band(0.9), "almost perfect")

    def test_analyse_gold_and_disagreements(self):
        rows = [ann("A", "1", "1"), ann("B", "1", "1"), ann("A", "2", "0"), ann("B", "2", "1"),
                ann("A", "3", "unsure"), ann("B", "3", "0"), ann("A", "4", "0"), ann("B", "4", "0")]
        r = annotation.analyse(rows)
        self.assertEqual(set(r["gold"]), {"1", "4"})
        self.assertEqual(len(r["disagreements"]), 1)
        self.assertEqual(r["unsure"], 1)
        self.assertEqual(r["n_compared"], 3)

    def test_single_annotator_and_next_pair(self):
        self.assertEqual(annotation.analyse([ann("A", "1", "1")])["gold"], {})
        pairs = [{"pair_id": "1"}, {"pair_id": "2"}]
        self.assertEqual(annotation.next_pair(pairs, [ann("A", "1", "1")], "A")[1]["pair_id"], "2")
        self.assertEqual(annotation.next_pair(pairs, [ann("A", "1", "1")], "B")[1]["pair_id"], "1")
        self.assertIsNone(annotation.next_pair(pairs, [ann("A", "1", "1"), ann("A", "2", "0")], "A")[1])

    def test_validation(self):
        self.assertFalse(annotation.valid_annotator("a b"))
        self.assertFalse(annotation.valid_annotator("x" * 21))
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):
                annotation.append_annotation(os.path.join(d, "a.csv"), "A1", {"pair_id": "1", "resume_id": "r", "job_id": "j"}, "maybe")


class TestEvaluation(unittest.TestCase):
    def test_evaluate_arms_prefers_informative_scorer(self):
        rng = random.Random(1)
        y = [rng.random() < 0.4 for _ in range(150)]
        y = [int(v) for v in y]
        good = [v * 0.6 + rng.random() * 0.5 for v in y]
        noise = [rng.random() for _ in y]
        import evaluate_on_human_labels as ev
        res = ev.evaluate_arms(y, {"model": good, "keyword": noise}, n_boot=300)
        self.assertGreater(res["arms"]["model"]["auc"], res["arms"]["keyword"]["auc"])
        lo, hi = res["diff_model_vs_keyword"]
        self.assertGreater(lo, 0)            # clearly better, CI excludes 0
        self.assertIn("ROC-AUC", ev.to_markdown(res, 0.5))

    def test_annotation_set_is_stratified(self):
        import make_annotation_set as m
        rows = [{"resume_id": f"R{i}", "job_id": f"J{i % 7}", "skill_match_score": str((i % 100) / 100)} for i in range(1000)]
        pairs = m.build(rows, 40, 0)
        self.assertEqual(len(pairs), 40)
        self.assertEqual(len({p["pair_id"] for p in pairs}), 40)
        self.assertEqual(pairs, m.build(rows, 40, 0))     # deterministic

    def test_semantic_with_stub_encoder(self):
        class Stub:
            def encode(self, texts):
                return [[1.0, 0.0] if "python" in t else [0.0, 1.0] for t in texts]
        s = semantic.cosine_scores(Stub(), ["python dev", "java dev"], ["python job", "python job"])
        self.assertAlmostEqual(s[0], 1.0); self.assertAlmostEqual(s[1], 0.0)


class TestAnnotateRoutes(unittest.TestCase):
    def make_app(self, tmp, enabled=True):
        import app as app_module, features
        from flask import Flask
        a = Flask(__name__, template_folder=str(app_module.BASE_DIR / "templates"))
        a.secret_key = "t"
        a.jinja_env.filters["skill_label"] = app_module.format_skill_label
        a.add_url_rule("/", "home", lambda: ""); a.add_url_rule("/model", "model_page", lambda: "")
        a.context_processor(lambda: {"show_model_page": False})
        pf, af = os.path.join(tmp, "pairs.csv"), os.path.join(tmp, "ann.csv")
        with open(pf, "w", newline="") as f:
            w = csv.writer(f); w.writerow(["pair_id", "resume_id", "job_id"])
            for r, j in list(zip(app_module.resumes[:3], app_module.jobs[:3])):
                w.writerow([f"{r['resume_id']}_{j['job_id']}", r["resume_id"], j["job_id"]])
        features.register_features(a, {
            "model": app_module.model, "taxonomy": app_module.taxonomy, "jobs": app_module.jobs,
            "resumes": app_module.resumes, "catalog": app_module.catalog, "skill_meta": app_module.skill_meta,
            "corpus_stats": app_module.corpus_stats, "study_file": os.path.join(tmp, "s.csv"),
            "annotate_enabled": enabled, "annotation_pairs_file": pf, "annotations_file": af})
        return a, af

    def test_disabled_by_default(self):
        with tempfile.TemporaryDirectory() as d:
            a, _ = self.make_app(d, enabled=False)
            self.assertEqual(a.test_client().get("/annotate").status_code, 404)

    def test_full_annotation_flow(self):
        with tempfile.TemporaryDirectory() as d:
            a, af = self.make_app(d)
            c = a.test_client()
            self.assertEqual(c.post("/annotate", data={"annotator": "bad name!"}).status_code, 400)
            self.assertEqual(c.post("/annotate", data={"annotator": "A1"}).status_code, 302)
            for _ in range(3):
                page = c.get("/annotate/task"); self.assertEqual(page.status_code, 200)
                self.assertNotIn(b"Match score", page.data)          # blinded to model output
                import re
                pid = re.search(rb'name="pair_id" value="([^"]+)"', page.data).group(1).decode()
                self.assertEqual(c.post("/annotate/task", data={"pair_id": pid}).status_code, 400)  # no label
                self.assertEqual(c.post("/annotate/task", data={"pair_id": "WRONG", "label": "1"}).status_code, 302)
                self.assertEqual(c.post("/annotate/task", data={"pair_id": pid, "label": "1"}).status_code, 302)
            self.assertIn(b"All 3 pairs done", c.get("/annotate/task").data)
            with open(af, newline="") as f:
                self.assertEqual(len(list(csv.DictReader(f))), 3)


if __name__ == "__main__":
    unittest.main()
